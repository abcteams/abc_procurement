<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'name', 'email', 'password','user_type',
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

    public function rules(){
        return $this->hasMany(rule::class);
    }

    public function getUsers($search = null){
        $q  =   DB::table('users');

        $value  =   $search['value'];
        if(isset($search['type']))
        {
            if($search['type'] == 'name'){
                $q->where('name','like','%'.$search['value'].'%');
            }elseif ($search['type'] == 'email'){
                $q->where('email','like','%'.$search['value'].'%');
            }else{
                $q->where(function($query )use ($value)
                {
                    $query->where('name', 'like', '%' . $value . '%')
                        ->orWhere('email', 'like', '%' . $value . '%');
                });
            }
        }
        $q->where('user_type', '=', $search['user']);
        $q->where('is_approved', '=', 1);

        $data   =   $q->orderBy('id', 'desc')->paginate(10);


        return $data;
    }


    public function getPendingUsers($type){
        $data = DB::table('users')
            ->where('user_type', '=', $type)
            ->where('is_approved', '=', 0)
            ->get();
        return $data;
    }


    public function approveUser($id){
        DB::table('users')
            ->where('id', $id)
            ->update(['is_approved' => '1']);
        return;
    }

    public function addRecord($data){
            $id = DB::table('users')->insertGetId(
                [
                    'name'          =>  $data['name'],
                    'email'         =>  $data['email'],
                    'password'      =>  $data['password'],
                    'remember_token'=>  $data['remember_token'],
                    'created_at'    =>  $data['created_at'],
                    'updated_at'    =>  $data['updated_at'],
                    'user_type'     =>  $data['user_type'],
                    'is_approved'   =>  $data['is_approved'],
                ]
            );

            DB::table('users_general_info')->insert(
                [
                    'user_id'           =>  $id,
                    'age'               =>  $data['age'],
                    'country'           =>  $data['country'],
                    'material_status'   =>  $data['material_status'],
                    'address'           =>  $data['address'],
                    'phone_number'      =>  $data['phone_number'],
                    'phone_number'      =>  $data['phone_number'],
                    'gender'            =>  $data['gender'],
                ]
            );

            DB::table('users_work_info')->insert(
                [
                    'user_id'               =>  $id,
                    'position_id'           =>  $data['position'],
                ]
            );

            if(intval($data['position']) > 0){
                $result = DB::table('position_rules')->where('position_id', '=', $data['position'])->get();
                foreach ($result as $k => $val)
                {
                    DB::table('rules')->insert(
                        [
                            'user_id'               =>  $id,
                            'screen_id'             =>  $val->screen_id,
                            'can_show'              =>  $val->can_show,
                            'can_edit'              =>  $val->can_edit,
                            'can_approve'           =>  $val->can_approve,
                            'can_approve2'          =>  $val->can_approve2,
                            'can_approve3'          =>  $val->can_approve3,
                        ]
                    );
                }
            }


    }

    public function getUserInfo($user_id){
        $data['main'] = DB::table('users')
            ->where('id', '=', $user_id)
            ->get();
        $data['genral'] = DB::table('users_general_info')
            ->join('country','users_general_info.country','country.id')
            ->where('user_id', '=', $user_id)
            ->get();
        $data['work'] = DB::table('users_work_info')
            ->join('positions','users_work_info.position_id','positions.id')
            ->where('user_id', '=', $user_id)
            ->get();

        return $data;
    }

    public function getUserRules($user_id){
        $data = DB::table('screens')
            ->leftJoin('rules', function ($join) use($user_id) {
                $join->on('screens.id', '=', 'rules.screen_id')->where('rules.user_id', '=', $user_id);
            })->select('screens.id as screen','screens.name','rules.*')->get();
        return $data;
    }
    public function getUserName($user_id){
        $data = DB::table('users')->where('id','=',$user_id)->get();

        return $data;
    }

    public function setRules($data,$user_id){
        foreach ($data as $k => $val)
        {
            DB::insert(
                "insert into `rules` (`user_id`, `screen_id`, `can_show`, `can_edit`, `can_approve` ,`can_approve2` ,`can_approve3`) 
                             values (
                             '$user_id', 
                             '$val[screen]', 
                             '$val[can_show]',
                             '$val[can_edit]',
                             '$val[can_approve]',
                             '$val[can_approve2]',
                             '$val[can_approve3]')
                on duplicate key update 
                            `can_show`='$val[can_show]',
                            `can_edit`='$val[can_edit]',
                            `can_approve`='$val[can_approve]',
                            `can_approve2`='$val[can_approve2]',
                            `can_approve3`='$val[can_approve3]'"
            );
        }
        return;
    }

    public function getPositions(){
        $data = DB::table('positions')->get();
        return $data;
    }
    public function getMyPositions($user_id){
        $data = DB::table('users_work_info')
            ->join('positions', 'positions.id', '=', 'users_work_info.position_id')
            ->where('users_work_info.user_id','=',$user_id)
            ->select('positions.*')->get();
        return $data;
    }
    public function getscreens(){
        $data = DB::table('screens')
            ->where('id','<','12')->get();
        return $data;
    }

    public function setPositions($data,$title,$position_id){

        DB::beginTransaction();
        try
        {
            if(intval($position_id) > 0)
            {
                DB::table('positions')->where('id', $position_id)->update(['title' => $title]);
                $id=intval($position_id);
            }
            else
            {
                $id = DB::table('positions')->insertGetId(['title'  =>  $title]);
            }

            foreach ($data as $k => $val)
            {
                DB::insert(
                    "insert into `position_rules` (`position_id`, `screen_id`, `can_show`, `can_edit`, `can_approve` ,`can_approve2` ,`can_approve3`) 
                             values (
                             '$id', 
                             '$val[screen]', 
                             '$val[can_show]',
                             '$val[can_edit]',
                             '$val[can_approve]',
                             '$val[can_approve2]',
                             '$val[can_approve3]')
                on duplicate key update 
                            `can_show`='$val[can_show]',
                            `can_edit`='$val[can_edit]',
                            `can_approve`='$val[can_approve]',
                            `can_approve2`='$val[can_approve2]',
                            `can_approve3`='$val[can_approve3]'"
                );
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
        }
    }

    public function getPositionScreens($position_id){
        $data = DB::table('screens')
            ->leftJoin('position_rules', function ($join) use($position_id) {
                $join->on('screens.id', '=', 'position_rules.screen_id')->where('position_rules.position_id', '=', $position_id);
            })
            ->join('positions', 'positions.id', '=', 'position_rules.position_id')
            ->where('screens.id','<','12')->select('screens.id as screen','screens.name','position_rules.*','positions.title as title')->get();
        return $data;
    }

    public function getPositionUsers($position_id){
        $data = DB::table('users_work_info')
            ->join('users','users_work_info.user_id','users.id')
            ->where('users_work_info.position_id','=',$position_id)->get();
        return $data;
    }

    public function getCountries(){
        $data = DB::table('country')->get();
        return $data;
    }

    public function userDetails($user_id,$data){

        DB::table('users_details')->insert(
            [
                'user_id'           =>  $user_id,
                'company_name'      =>  $data['company_name'],
                'phone_number'      =>  $data['phone_number'],
                'phone_number2'     =>  $data['phone2'],
                'country'           =>  $data['country'],
                'address'           =>  $data['address'],
            ]
        );
    }
}
