<?php

namespace App\Http\Controllers;

use App\important\checkAuth;
use App\important\checkMenu;
use App\Scl;
use Illuminate\Http\Request;

class SclController extends Controller
{
    private $menu;
    private $checkAuth;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->menu         =   new checkMenu();
        $this->checkAuth    =   new checkAuth();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function show(Request $request)
    {
        $authScl        =   $this->checkAuth->checkScl();

        if($authScl->can_show)
        {
            $search['type']     =   $request->type;
            $search['value']    =   $request->value;

            $scl    =   new Scl();
            $data   =   $scl->fetchAll($search);

            $menuData   =   $this->menu->Menu('scl','showScl');
            return view('SCL.show')->with('menu',$menuData)->with('data',$data)->with('auth',$authScl);
        }
        else{
            return view('home');
        }
    }

    public function showsub(Request $request){
        $authScl        =   $this->checkAuth->checkScl();
        if($authScl->can_show)
        {
            $search['type']     =   $request->type;
            $search['value']    =   $request->value;
            $search['id']       =   $request->id;

            $scl    =   new Scl();
            $data   =   $scl->getSub($search);

            $menuData   =   $this->menu->Menu('scl','');
            return view('SCL.subscl')->with('menu',$menuData)->with('data',$data)->with('sclId',$request->id)->with('auth',$authScl);;
        }
        else{
            return view('home');
        }
    }

    public function add(Request $request){
        $authScl        =   $this->checkAuth->checkScl();
        $menuData   =   $this->menu->Menu('scl','addScl');
        if($authScl->can_edit) {
            if (isset($request->id) && $request->id > 0) {
                $scl    =   new Scl();
                $data = $scl->getRecord($request->id);

                return view('SCL.add')->with('menu', $menuData)->with('theRecord', $data);
            } else {
                return view('SCL.add')->with('menu', $menuData)->with('subMenu', 'add');
            }
        }
        else{
            return view('home')->with('menu', $menuData);
        }

    }

    public function addScl(Request $request){

        $this->validate($request, [
            'title' => 'required',
        ]);

        $authScl        =   $this->checkAuth->checkScl();
        if($authScl->can_edit) {
            $data   =   array();
            $data['title']  =   $request->title;
            $data['desc']   =   $request->description;
            $scl    =   new Scl();
            if(isset($request->id )&& $request->id > 0) {
                $data['id']   =   $request->id;
                $scl->updateRecord($data);
            }else{
                $scl->addRecord($data);
            }
            $menuData   =   $this->menu->Menu('scl','showScl');
            return redirect('scl/show')->with('menu', $menuData);
        }
        else{
            $menuData   =   $this->menu->Menu('');
            return view('home')->with('menu', $menuData);
        }
    }



    public function addsub(Request $request){
        $authScl        =   $this->checkAuth->checkScl();
        if($authScl->can_edit) {
            $menuData   =   $this->menu->Menu('scl','');
            if (isset($request->sclId) && $request->sclId) {
                if (isset($request->id) && $request->id > 0) {
                    $scl    =   new Scl();
                    $data = $scl->getSubRecord($request->id);

                    return view('SCL.addsub')->with('menu', $menuData)->with('theRecord', $data)->with('sclId', $request->sclId);
                } else {
                    return view('SCL.addsub')->with('menu', $menuData)->with('sclId', $request->sclId);
                }
            }
        }

    }

    public function addsubscl(Request $request){

        $this->validate($request, [
            'title' => 'required',
        ]);

        $authScl        =   $this->checkAuth->checkScl();
        if($authScl->can_edit) {
            if (isset($request->sclId) && $request->sclId > 0) {
                $data = array();
                $data['sclId'] = $request->sclId;
                $data['title'] = $request->title;
                $data['desc'] = $request->description;

                $scl    =   new Scl();
                if (isset($request->id) && $request->id > 0) {
                    $data['id'] = $request->id;
                    $scl->updateSubRecord($data);
                } else {
                    $scl->addSubRecord($data);
                }
            }
        }

        return redirect('scl/showsub/'.$request->sclId);
    }


    public function sclSearch(Request $request){
        $data['type']       =   $request->type;
        $data['search']     =   $request->search;

        $scl    =   new Scl();
        $result =   $scl->searchScl($data);

        die(json_encode($result));
        die('0');
    }

    public function subSclSearch(Request $request){
        $data['scl_id']       =   $request->scl_id;
        $data['type']       =   $request->type;
        $data['search']     =   $request->search;

        $scl    =   new Scl();
        $result =   $scl->searchSubScl($data);

        die(json_encode($result));
        die('0');
    }

    public function removescl(Request $request)
    {
        $authScl = $this->checkAuth->checkScl();
        if ($authScl->can_edit) {

            $scl    =   new Scl();
            $recNumber   = $scl->checkSclIsUsed($request->id);
            if(intval($recNumber) > 0){
                die('This Record Is Used , You Cant Remove it');
            }else{
                $scl->removeRec($request->id);
            }
        }
        die();
    }
    public function removesubscl(Request $request){
        $authScl = $this->checkAuth->checkScl();
        if ($authScl->can_edit) {
            $scl    =   new Scl();
            $subRecNumber   = $scl->checkSubGmlIsUsed($request->id);
            if(intval($subRecNumber) > 0){
                die('This Record Is Used , You Cant Remove it');
            }else{
                $scl->removeSubScl($request->id);
            }


        }
        die();
    }

    public function pendingSub(Request $request)
    {
        $scl    =   new Scl();
        $data = $scl->getPending($request->id);
        $menuData   =   $this->menu->Menu('scl','pendingScl');
        return view ('SCL.pending')->with('menu',$menuData)->with('data',$data);
    }

    public function approvePending(Request $request){
        $authScl = $this->checkAuth->checkScl();
        if ($authScl->can_approve) {
            if (isset($request->id) && $request->id > 0) {
                $scl    =   new Scl();
                $data = $scl->approvePending($request->id);
            }
            return back();
        }
    }

}
