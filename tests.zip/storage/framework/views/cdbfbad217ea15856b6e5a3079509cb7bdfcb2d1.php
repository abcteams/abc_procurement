<?php $__env->startSection('content'); ?>

<ul class="breadcrumb">
    <li><a href="#">Home</a></li>
    <li class="active">Subcontractor Proposal</li>
</ul>

<div class="page-title">
    <h2>Subcontractor Proposal</h2>
</div>

<div class="page-content-wrap">
    <div class="row">
        <div class="col-md-12">
                <div class="panel panel-default">
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('subcontractor/addProposal')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="panel-heading">
                            <h3 class="panel-title">Proposal</h3>
                        </div>
                        <div class="panel-body">
                            <br>
                            <div class="row">
                                <div class="col-md-1">
                                </div>
                                <div class="col-md-9">
                                    <div class="form-group">
                                        <label for="name" class="col-md-2 control-label">Proposal</label>
                                        <div class="col-md-10">
                                            <div class="input-group" style="width: 100%">
                                               <input type="text" class="form-control" name="proposal" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2"></div>
                            </div>
                            <br>
                            <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <table class="table table-bordered table-striped table-actions">
                                            <thead>
                                            <tr>
                                                <th>Category</th>
                                                <th>Quantity</th>
                                                <th>Price</th>
                                                <th>Description ( Optional ) </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <input type="hidden" value="<?php echo e($val->main_id); ?>" name="subcontractor_request[]">
                                                    <input type="hidden" value="<?php echo e($val->scr_id); ?>" name="scr[]">
                                                    <input type="hidden" value="<?php echo e($val->id); ?>" name="id[]">
                                                    <td><?php echo e($val->title); ?></td>
                                                    <td><?php echo e($val->quantity); ?></td>
                                                    <td><input type="number" name="price[]" step="0.01" value="0.00"> </td>
                                                    <td><input type="text" name="description[]" style="width: 100%"> </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-2"></div>
                                        <div class="col-md-10">
                                            <div class="errorMasseges" style="padding:10px 0px">
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="alert alert-danger"><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2"></div>
                            </div>
                        <div class="panel-footer">
                            <input style="margin-left:10px;width:70px" type="submit" value="<?php echo e(isset($theRecord[0])?'update':'add'); ?>" class="btn btn-primary pull-right" />
                            <a href="<?php echo e(asset('subcontractor/pendinginquiry')); ?>" style="width:70px" class="btn btn-danger pull-right" >Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- END PAGE CONTENT -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>