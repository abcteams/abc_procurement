<?php

namespace App\Http\Controllers;

use App\important\checkAuth;
use App\important\checkMenu;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class UsersController extends Controller
{
    private $menu;
    private $checkAuth;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->menu         =   new checkMenu();
        $this->checkAuth    =   new checkAuth();
    }

    public function showUsers(Request $request){
        $authSupplier        =   $this->checkAuth->checkSupplier();
        if($authSupplier->can_show)
        {

            $search['type']     =   $request->type;
            $search['value']    =   $request->value;
            $search['user']     =   1;

            $users  =   new User();
            $data   =   $users->getUsers($search);

            $menuData   =   $this->menu->Menu('settings','showUsers');
            return view('Users.showUsers')->with('menu',$menuData)->with('data',$data);
        }
        else{
            return view('home');
        }
    }

    public function showSuppliers(Request $request){
        $authSupplier        =   $this->checkAuth->checkSupplier();
        if($authSupplier->can_show)
        {
            $search['type']     =   $request->type;
            $search['value']    =   $request->value;
            $search['user']     =   2;

            $users  =   new User();
            $data   =   $users->getUsers($search);

            $menuData   =   $this->menu->Menu('showSupplieras','showSupplieras');
            return view('Users.showSuppliers')->with('menu',$menuData)->with('data',$data);
        }
        else{
            return view('home');
        }
    }

    public function pendingSuppliers(){
        $authSupplier        =   $this->checkAuth->checkSupplier();
        if($authSupplier->can_approve)
        {
            $users  =   new User();
            $data   =   $users->getPendingUsers('2');

            $menuData   =   $this->menu->Menu('showSupplieras','pendingSuppliers');
            return view('Users.pendingSuppliers')->with('menu',$menuData)->with('data',$data);
        }
        else{
            return view('home');
        }
    }
    public function showSubcontractor(Request $request){
        $authSupplier        =   $this->checkAuth->checkSupplier();
        if($authSupplier->can_show)
        {
            $search['type']     =   $request->type;
            $search['value']    =   $request->value;
            $search['user']     =   3;

            $users  =   new User();
            $data   =   $users->getUsers($search);

            $menuData   =   $this->menu->Menu('subcont','showSubcont');
            return view('Users.showSubcontractors')->with('menu',$menuData)->with('data',$data);
        }
        else{
            return view('home');
        }
    }

    public function pendingSubcontractor(){
        $authSupplier        =   $this->checkAuth->checkSupplier();
        if($authSupplier->can_approve)
        {
            $users  =   new User();
            $data   =   $users->getPendingUsers('3');

            $menuData   =   $this->menu->Menu('subcont','pendingSubcont');
            return view('Users.pendingSubcontractors')->with('menu',$menuData)->with('data',$data);
        }
        else{
            return view('home');
        }
    }
    public function approveUser(Request $request){
        $authSupplier        =   $this->checkAuth->checkSupplier();
        if($authSupplier->can_approve) {
            $users  =   new User();
            $users->approveUser($request->id);
        }
        return redirect()->back();
    }

    public function addUser(Request $request){
        $authUsers        =   $this->checkAuth->checkUsers();
        $menuData   =   $this->menu->Menu('settings','showUsers');
        if($authUsers->can_edit) {
            $data   =   array();
            $this->validate($request, [
                'name'              => 'required|string|max:255',
                'email'             => 'required|string|email|max:255|unique:users',
                'age'               => 'required',
                'country'           => 'required',
                'gender'            => 'required|string|max:255',
                'material_status'   => 'required|string|max:255',
            ]);

            $data['name']                   =   $request->name;
            $data['email']                  =   $request->email;
            $data['password']               =   Hash::make('User123!');
            $data['remember_token']         =   $request->_token;
            $data['created_at']             =   date("Y-m-d H:i:s");
            $data['updated_at']             =   date("Y-m-d H:i:s");
            $data['user_type']              =   1;
            $data['is_approved']            =   1;
            $data['age']                    =   $request->age;
            $data['country']                =   $request->country;
            $data['gender']                 =   $request->gender;
            $data['material_status']        =   $request->material_status  ;
            $data['address']                =   $request->address;
            $data['phone_number']           =   $request->phone_number;
            $data['position']               =   $request->position;
            $User    =   new User();

            if(isset($request->id )&& $request->id > 0) {
                $data['id']   =   $request->id;
                $User->updateRecord($data);
            }else{
                $User->addRecord($data);
            }
            return redirect()->action('UsersController@showUsers');
        }
        else{
            $menuData   =   $this->menu->Menu('menu', $menuData);
            return view('home')->with('menu', $menuData);
        }

    }
    public function add(Request $request){
        $authUsers        =   $this->checkAuth->checkUsers();
        $menuData   =   $this->menu->Menu('settings','showUsers');
        $user       =   new User();

        if(Auth::user()->id     ==  1)
            $positions  =   $user->getPositions();
        else
            $positions  =   $user->getMyPositions(Auth::user()->id);

        $Countries  =   $user->getCountries();
        if($authUsers->can_edit) {
            if (isset($request->id) && $request->id > 0) {
                $data = $user->getUserInfo($request->id);
                return view('Users.add')
                    ->with('menu', $menuData)
                    ->with('theRecord', $data)
                    ->with('countries', $Countries)
                    ->with('positions',$positions);
            } else {
                return view('Users.add')
                    ->with('menu', $menuData)
                    ->with('countries', $Countries)
                    ->with('positions',$positions);
            }
        }
        else{
            return view('home')->with('menu', $menuData);
        }

    }

    public function showuserprofiel(Request $request){
        $authUsers        =   $this->checkAuth->checkUsers();
        $menuData   =   $this->menu->Menu('settings','showUsers');
        if($authUsers->can_show) {

            $user = new User();
            $data = $user->getUserInfo($request->id);

            return view('Users.userInfo')->with('menu', $menuData)->with('data', $data);

        } else{
            return view('home')->with('menu', $menuData);
        }
    }

    public function usersrules(Request $request){
        $authRules        =   $this->checkAuth->checkRules();
        $menuData   =   $this->menu->Menu('settings','showRules');
        if($authRules->can_show) {
            $users  =   new User();
            $data   = $users->getUserRules($request->id);
            $user   = $users->getUserName($request->id);
            return view('Users.usersRules')->with('menu', $menuData)->with('data', $data)->with('user',$user);

        } else{
            return view('home')->with('menu', $menuData);
        }
    }

    public function setTheRules(Request $request){
        $authRules        =   $this->checkAuth->checkRules();
        if($authRules->can_edit) {
            $data       =   $request->data;
            $user_id    =   $request->id;

            $user   =   new User();
            $user->setRules($data,$user_id);
        }
        print_r($request->post());die();
        die('xxxx');
    }

    public function setThePositions(Request $request){
        $authRules        =   $this->checkAuth->checkPositions();
        if($authRules->can_edit) {
            $data       =   $request->data;
            $title      =   $request->title;
            $position_id=   $request->id;

            $user       =   new User();
            $user->setPositions($data,$title,$position_id);
        }
        die('xxxx');
    }

    public function showPositions(){
        $authRules        =   $this->checkAuth->checkPositions();
        if($authRules->can_show) {
            $users  =   new User();
            $data   =   $users->getPositions();

            $menuData   =   $this->menu->Menu('settings','showPositions');
            return view('Users.showPositions')->with('menu',$menuData)->with('data',$data)->with('auth',$authRules);
        }
        else{
            return view('home');
        }
    }
    public function addPosition(Request $request){
        $authRules        =   $this->checkAuth->checkPositions();
        if($authRules->can_edit) {
            $users  =   new User();

            if(isset($request->id) && $request->id > 0){
                $data   =   $users->getPositionScreens($request->id);
            }else{
                $data   =   $users->getscreens();
            }

            $menuData   =   $this->menu->Menu('settings','showPositions');
            return view('Users.addPosition')->with('menu',$menuData)->with('data',$data);
        }
        else{
            return view('home');
        }
    }

    public function positionUsers(Request $request){
       $menuData   =   $this->menu->Menu('settings','showPositions');
       $users  =   new User();
       $data   =   $users->getPositionUsers($request->id);
       return view('Users.positionUsers')->with('menu',$menuData)->with('data',$data);
    }
}
