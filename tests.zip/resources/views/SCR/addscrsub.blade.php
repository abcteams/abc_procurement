@extends('layouts.master')
@section('content')
    <ul class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li class="active">Sub Subcontractor Request </li>
        <li class="active">Add Sub Request</li>
    </ul>
    <div class="page-title">
        <h2>Add Sub Subcontractor Request</h2>
    </div>
    <!-- PAGE CONTENT WRAPPER -->
    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">
        <div class="row">
            <div class="col-md-12">
                <div style="padding:10px">
                    <div class="panel panel-default">
                        <form class="form-horizontal" method="POST" action="{{ url('scr/addscrsubcategory') }}">
                             {{ csrf_field() }}
                            <input type="hidden" name="id" value="{{isset($theRecord[0])?$theRecord[0]->id:'0'}}" >
                            <input type="hidden" name="scr_id" value="{{$scr_id}}" >

                            <div class="panel-heading">
                                <h3 class="panel-title">Add</h3>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-md-2 control-label">Quantity</label>
                                            <div class="col-md-10">
                                                <div class="input-group" {{ $errors->default->has('quantity') ?  $errors->default->first('quantity') : '' }} style="width: 100%">
                                                    <input id="quantity" type="number" value="{{isset($theRecord[0])?$theRecord[0]->quantity:''}}" class="form-control" name="quantity" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-md-2 control-label">Budgetory Price</label>
                                            <div class="col-md-10">
                                                <div class="input-group" {{ $errors->default->has('budgetory') ?  $errors->default->first('budgetory') : '' }} style="width: 100%">
                                                    <input id="budgetory" type="number" step="0.01" value="{{isset($theRecord[0])?$theRecord[0]->budgetory_price:''}}" class="form-control" name="budgetory" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-md-2 control-label">Description</label>
                                            <div class="col-md-10">
                                                <div class="input-group" {{ $errors->default->has('size') ?  $errors->default->first('size') : '' }} style="width: 100%">
                                                    <textarea id="description" class="form-control" name="description" >{{isset($theRecord[0])?$theRecord[0]->description:''}}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br />

                            <div class="panel-footer">

                                <input style="margin-left:10px;width:70px" type="submit" value="{{isset($theRecord[0])?'update':'add'}}" class="btn btn-primary pull-right" />
                                <a href="{{asset('scr/showsubscr/'.$scr_id)}}" style="width:70px" class="btn btn-danger pull-right" >Cancel</a>
                            </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT -->
    </div>
    <script src="{{ asset('js/SCR/main.js') }}"></script>
@endsection
