@extends('layouts.master')
@section('content')
    <ul class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li class="active">Materials </li>
        <li class="active">Add Material</li>
    </ul>
    <div class="page-title">
        <h2>Add Material</h2>
    </div>
    <!-- PAGE CONTENT WRAPPER -->
    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">
        <div class="row">
            <div class="col-md-12">
                <div style="padding:10px">
                    <div class="panel panel-default">
                        <form class="form-horizontal" method="POST" action="{{ url('boq/addboqsubmaterilas') }}">
                             {{ csrf_field() }}
                            <input type="hidden" name="id" value="{{isset($theRecord[0])?$theRecord[0]->id:'0'}}" >
                            <input type="hidden" name="boq_id" value="{{$boq_id}}" >

                            <div class="panel-heading">
                                <h3 class="panel-title">Add</h3>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-md-2 control-label">Quantity</label>
                                            <div class="col-md-10">
                                                <div class="input-group" {{ $errors->default->has('quantity') ?  $errors->default->first('quantity') : '' }} style="width: 100%">
                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                    <input id="quantity" type="number" value="{{isset($theRecord[0])?$theRecord[0]->quantity:''}}" class="form-control" name="quantity" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-md-2 control-label">Budgetory Price</label>
                                            <div class="col-md-10">
                                                <div class="input-group" {{ $errors->default->has('budgetory') ?  $errors->default->first('budgetory') : '' }} style="width: 100%">
                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                    <input id="budgetory" type="number" step="0.01" value="{{isset($theRecord[0])?$theRecord[0]->budgetory_price:''}}" class="form-control" name="budgetory" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-md-2 control-label">Size</label>
                                            <div class="col-md-10">
                                                <div class="input-group" {{ $errors->default->has('size') ?  $errors->default->first('size') : '' }} style="width: 100%">
                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                    <input id="size" type="number" value="{{isset($theRecord[0])?$theRecord[0]->size:''}}" class="form-control" name="size" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="name" class="col-md-2 control-label">Unit</label>
                                            <div class="col-md-10">
                                                <div class="input-group" {{ $errors->default->has('unit') ?  $errors->default->first('unit') : '' }} style="width: 100%">
                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                    <input id="unit" type="text" value="{{isset($theRecord[0])?$theRecord[0]->unit:''}}" class="form-control" name="unit" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="material_specs" class="col-md-2 control-label" style="line-height: 15px;">Custom Material Specs (Optional)</label>
                                            <div class="col-md-10">
                                                <div class="input-group" style="width: 100%">
                                                    <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                                    <input id="material_specs" type="text" value="{{isset($theRecord[0])?$theRecord[0]->custom_material_specs:''}}" class="form-control" name="material_specs" >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <div class="col-md-2"></div>
                                            <div class="col-md-10">
                                                <div class="errorMasseges" style="padding:10px 0px">
                                                @foreach ($errors->all() as $error)
                                                    <li class="alert alert-danger">{{ $error }}</li>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                            <div class="panel-footer">

                                <input style="margin-left:10px;width:70px" type="submit" value="{{isset($theRecord[0])?'update':'add'}}" class="btn btn-primary pull-right" />
                                <a href="{{asset('boq/showsubboq/'.$boq_id)}}" style="width:70px" class="btn btn-danger pull-right" >Cancel</a>
                            </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT -->
    </div>

    <script src="{{ asset('js/BOQ/main.js') }}"></script>
@endsection
