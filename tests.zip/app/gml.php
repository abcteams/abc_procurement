<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class gml extends Model
{
    public function fetchAll($search = null){

        $q  =   DB::table('gml');

        if(isset($search['type']))
        {
            if($search['type'] == 'title'){
                $q->where('title','like','%'.$search['value'].'%');
            }elseif ($search['type'] == 'desc'){
                $q->where('description','like','%'.$search['value'].'%');
            }else{
                $q->where('title','like','%'.$search['value'].'%');
                $q->orWhere('description','like','%'.$search['value'].'%');
            }
        }

        $data   =   $q->orderBy('id', 'desc')->paginate(10);
        return $data;
    }

    public function getSub($search = null){
        $q  =   DB::table('sub_gml');

        $value  =   $search['value'];
        if(isset($search['type']))
        {
            if($search['type'] == 'title'){
                $q->where('title','like','%'.$search['value'].'%');
            }elseif ($search['type'] == 'desc'){
                $q->where('description','like','%'.$search['value'].'%');
            }else{
                $q->where(function($query )use ($value)
                {
                    $query->where('title', 'like', '%' . $value . '%')
                        ->orWhere('description', 'like', '%' . $value . '%');
                });
            }
        }

        $q->where('gml_id', '=', $search['id']);
        $q->where('is_approved', '=', 1);

        $data   =   $q->orderBy('id', 'desc')->paginate(10);

        return $data;
    }


    public function getSubGml($id){
        $q  =   DB::table('sub_gml');
        $q->where('gml_id', '=', $id);
        $data   =   $q->orderBy('id', 'desc')->get();
        return $data;
    }

    public function addRecord($data){
        DB::table('gml')->insert(
            ['title' => $data['title'], 'description' => $data['desc']]
        );
    }

    public function searchGml($data){

        $type   =   $data['type'];

        if(trim($type) == 'title'){
            $result = DB::table('gml')->where('title', 'like', '%'.$data['search'].'%')->orderBy('id', 'desc')->get();
        }elseif (trim($type) == 'desc')
        {
            $result = DB::table('gml')->where('description', 'like', '%'.$data['search'].'%')->orderBy('id', 'desc')->get();
        }else{
            $result = DB::table('gml')
                ->where('title', 'like', '%'.$data['search'].'%')
                ->orWhere('description', 'like', '%'.$data['search'].'%')
                ->orderBy('id', 'desc')
                ->get();
        }
        return $result;
    }

    public function searchSubGml($data){

        $type   =   $data['type'];

        if(trim($type) == 'title'){
            $result = DB::table('sub_gml')->where('gml_id', '=', $data['gml_id'])->where('title', 'like', '%'.$data['search'].'%')->where('is_approved', '=', 1)->orderBy('id', 'desc')->get();
        }elseif (trim($type) == 'desc')
        {
            $result = DB::table('sub_gml')->where('gml_id', '=', $data['gml_id'])->where('description', 'like', '%'.$data['search'].'%')->where('is_approved', '=', 1)->orderBy('id', 'desc')->get();
        }else{
            $result = DB::table('sub_gml')
                ->where('gml_id', '=', $data['gml_id'])
                ->where(function($query )use ($data)
                {
                    $query->where('title', 'like', '%' . $data['search'] . '%')
                        ->orWhere('description', 'like', '%' . $data['search'] . '%');
                })
                ->where('is_approved', '=', 1)
                ->orderBy('id', 'desc')
                ->get();
        }
        return $result;
    }



    public function getRecord($id){
        $data = DB::table('gml')->where('id', '=', $id)->get();

        return $data;
    }

    public function getSubRecord($id){
    $data = DB::table('sub_gml')->where('id', '=', $id)->get();

    return $data;
}

    public function updateRecord($data){
        DB::table('gml')
            ->where('id', $data['id'])
            ->update(['title' => $data['title'] , 'description'=>$data['desc']]);
    }

    public function checkGmlIsUsed($id){
        $count  =   DB::table('sub_gml')->where('gml_id','=',$id)->count();
        return $count;
    }

    public function removeRec($id)
    {
        DB::table('gml')->where('id', '=', $id)->delete();
    }


    public function addSubRecord($data){
        DB::table('sub_gml')->insert(
            ['gml_id' => $data['gmlId'],'title' => $data['title'], 'description' => $data['desc'],'is_approved'=>'0']
        );
    }

    public function checkSubGmlIsUsed($id){
        $count  =   DB::table('boq')->where('sub_gml_id','=',$id)->count();
        return $count;
    }

    public function updateSubRecord($data){
        DB::table('sub_gml')
            ->where('id', $data['id'])
            ->update(['title' => $data['title'] , 'description'=>$data['desc']]);
    }


    public function removeSubGml($id)
    {
        DB::table('sub_gml')->where('id', '=', $id)->delete();
        DB::table('supplier_materials')->where('submaterila_id', '=', $id)->delete();
    }

    public function getPending($id){
        if(isset($id) && $id > 0)
        {
            $data   =   DB::table('sub_gml')->where('is_approved', '=', 0)->where('gml_id', '=', $id)->orderBy('id', 'desc')->get();
        }else{
            $data   =   DB::table('sub_gml')->where('is_approved', '=', 0)->orderBy('id', 'desc')->get();
        }
        return $data;
    }

    public function approvePending($id){
        DB::table('sub_gml')
            ->where('id', $id)
            ->update(['is_approved' =>1]);
    }
}

