$(function() {
    $('.select2').select2();
});

function getSubScl(item){
    var subScl=$('#subScl');
    if(item.value != 0){
        subScl.prop('disabled', false);
        $.ajax({
            type: "GET",
            url: 'getsubsclitems',
            data:{'scl_id':item.value},
            success: function(result) {
                var obj = JSON.parse(result);

                subScl.find('option').remove();
                if(obj.length > 0)
                {
                    subScl.append($("<option></option>")
                        .attr("value",'0')
                        .text('Choose Sub Scl'));

                    $.each(obj , function( index, value ) {
                        subScl.append($("<option></option>")
                            .attr("value",value.id)
                            .text(value.title));

                    });
                }else{
                    subScl.append($("<option></option>")
                        .attr("value",'0')
                        .text('No Sub Items'));
                }
            }
        });
    }else{
        subScl.find('option').remove();
        subScl.append($("<option></option>")
            .attr("value",'0')
            .text('Choose Sub Scl'));

        subScl.prop('disabled', 'disabled');
    }

}



function delete_row(id){
    swal({
        title: "Are you sure?",
        text: "Are You sure you Want to Delete this record!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "GET",
                    url: 'removeCategotry',
                    data:{'id':id},
                    success: function(data) {
                        location.reload();
                    }
                });
            }
        });

}