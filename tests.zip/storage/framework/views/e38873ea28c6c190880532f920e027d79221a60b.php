    <div class="page-sidebar">
    <!-- START X-NAVIGATION -->
    <ul class="x-navigation">
        <li class="xn-logo">
            <a href="index-2.html">ATLANT</a>
            <a href="#" class="x-navigation-control"></a>
        </li>
        <li class="xn-profile">
            <a href="#" class="profile-mini">
                <img src="<?php echo e(asset('img/profile.jpg' )); ?>"/>
            </a>
            <div class="profile">
                <a href="../materials/userProfile">
                    <div class="profile-image">
                        <img  src="<?php echo e(asset('img/profile.jpg' )); ?>" />
                    </div>
                </a>
                <div class="profile-data">
                    <div class="profile-data-name">Miqdad Abu ateleh</div>
                    <div class="profile-data-title">Web Developer/Designer</div>
                </div>
            </div>
        </li>
        <li class="xn-title">Navigation</li>
        <li class="xn-openable">
            <a href="#"><span class="glyphicon glyphicon-home"></span> <span class="xn-text">HOME</span></a>
        </li>
        <li class="xn-openable">
            <a href="#"><span class="fa fa-sitemap"></span> <span class="xn-text">GML</span></a>
            <ul>
                <li><a href="@Url.Action("show", "GML")"><span class="fa fa-list-ul"></span>View All</a></li>
                <li><a href="@Url.Action("pending", "GML")"><span class="fa fa-clock-o"></span>Pending</a></li>
                <li><a href="@Url.Action("add", "GML")"><span class="fa fa-pencil"></span>Add</a></li>
            </ul>
        </li>
        <li class="xn-openable">
            <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Work Zone</span></a>
            <ul>
                <li><a href="@Url.Action("show", "WorkZone")"><span class="fa fa-list-ul"></span>View All</a></li>
                <li><a href="@Url.Action("add", "WorkZone")"><span class="fa fa-pencil"></span>Add WorkZone</a></li>
                <li class="xn-openable">
                    <a href="#"><span class="fa fa-file-text-o"></span> <span class="xn-text">Material Inquiry</span></a>
                    <ul>
                        <li><a href="@Url.Action("show", "MaterialInquiry")"><span class="fa fa-list-ul"></span>View All Materials</a></li>
                        <li><a href="@Url.Action("pending", "MaterialInquiry")"><span class="fa fa-clock-o"></span>Pending Materials</a></li>
                        <li><a href="@Url.Action("closed", "MaterialInquiry")"><span class="fa fa-clock-o"></span>Closed Material</a></li>
                    </ul>
                <li><a href="@Url.Action("add", "WorkZone")"><span class="fa fa-outdent"></span>LPOs</a></li>
                <li><a href="@Url.Action("add", "WorkZone")"><span class="glyphicon glyphicon-inbox"></span>Invoice</a></li>
                <li><a href="@Url.Action("add", "WorkZone")"><span class="glyphicon glyphicon-random"></span>Performa</a></li>
                </li>
            </ul>
        </li>
        <li class="xn-openable">
            <a href="#"><span class="fa fa-file-text-o"></span> <span class="xn-text">Subcontractor</span></a>
            <ul>
                <li><a href="/Subcontractor/all"><span class="fa fa-list-ul"></span>View All</a></li>
                <li class="xn-openable">
                    <a href="#"><span class="fa fa-sitemap"></span> <span class="xn-text">SCL</span></a>
                    <ul>
                        <li><a href="@Url.Action("show", "SCL")"><span class="fa fa-list-ul"></span>View All</a></li>
                        <li><a href="@Url.Action("add", "SCL")"><span class="fa fa-pencil"></span>Add</a></li>
                    </ul>
                </li>
                <li class="xn-openable">
                    <a href="#"><span class="fa fa-file-text-o"></span> <span class="xn-text">Subcontractor Request</span></a>
                    <ul>
                        <li><a href="@Url.Action("show", "SubcontractorRequest")"><span class="fa fa-list-ul"></span>View All</a></li>
                        <li><a href="@Url.Action("pending", "SubcontractorRequest")"><span class="fa fa-clock-o"></span>Pending</a></li>
                        <li><a href="@Url.Action("closed", "SubcontractorRequest")"><span class="fa fa-clock-o"></span>Closed</a></li>
                    </ul>
                </li>
            </ul>

        </li>

        <li class="xn-openable">
            <a href="#"><span class="fa fa-file-text-o"></span> <span class="xn-text">Supplier</span></a>
            <ul>
                <li><a href="/Supplier/all"><span class="fa fa-list-ul"></span>View All</a></li>
                <li><a href="/Supplier/pending"><span class="fa fa-clock-o"></span>Pending</a></li>
            </ul>
        </li>
        <li class="xn-openable">
            <a href="#"><span class="fa fa-shopping-cart"></span> <span class="xn-text">Cart</span></a>
            <ul>
                <li><a href="@Url.Action("Cart", "MaterialRequisition")"><span class="fa fa-list-ul"></span>View</a></li>

            </ul>
        </li>
        <li class="xn-openable">
            <a href="#"><span class="fa fa-gear"></span> <span class="xn-text">Settings</span></a>
            <ul>
                <li><a href="../materials/users"><span class="fa fa-users"></span>Users</a></li>
                <li><a href="../materials/mainRole"><span class="fa fa-clock-o"></span>Users Rules</a></li>
                <li><a href="../materials/positionRules"><span class="fa fa-clock-o"></span>Positions Rules</a></li>
            </ul>
        </li>
    </ul>  <!-- END X-NAVIGATION -->
    </div>
