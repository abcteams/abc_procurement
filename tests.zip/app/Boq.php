<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Boq extends Model
{
    public function fetchAll($search = null){
        $q = DB::table('boq');
        $q->join('sub_gml', 'boq.sub_gml_id', '=', 'sub_gml.id');
        $q->join('gml', 'gml.id', '=', 'sub_gml.gml_id');
        $q->join('boq_status', 'boq.status', '=', 'boq_status.id');
        $q->select('boq.*','sub_gml.title', 'sub_gml.description','gml.title as gml_title','boq_status.status as status');
        $value  =   $search['value'];

        if(isset($search['type']))
        {
            if($search['type'] == 'title'){
                $q->where('gml.title','like','%'.$search['value'].'%');
            }elseif ($search['type'] == 'sub_title'){
                $q->where('sub_gml.title','like','%'.$search['value'].'%');
            }elseif ($search['type'] == 'desc'){
                $q->where('sub_gml.description','like','%'.$search['value'].'%');
            }else{
                $q->Where(function($query )use ($value){
                    $query->where('gml.title','like','%'.$value.'%');
                    $query->orWhere('sub_gml.title','like','%'.$value.'%');
                    $query->orWhere('sub_gml.description','like','%'.$value.'%');
                });

            }
        }

        $q->where('boq.sub_work_zone_id', '=', $search['id']);
        $data   =   $q->orderBy('id', 'desc')->paginate(10);
        return $data;


        return $data;
    }

    public function addRecord($data){
        DB::table('boq')->insert(
            ['sub_work_zone_id' => $data['workzoneId'], 'sub_gml_id' => $data['sub_gml_id'],'status' => '1']
        );
    }

    public function updateRecord($data){
        DB::table('boq')
            ->where('id', $data['id'])
            ->update(['sub_gml_id' => $data['sub_gml_id']]);
    }

    public function showsubboq($id){
        $data   =   DB::table('boq_sub_materials')
            ->join('boq', 'boq.id', '=', 'boq_sub_materials.boq_id')
            ->select('boq_sub_materials.*','boq.inquiry_is_created','boq.status')
            ->where('boq_id', '=', $id)
            ->orderBy('id', 'desc')->get();
        return $data;
    }

    public function addsubRecord($data){
        DB::table('boq_sub_materials')->insert(
            ['boq_id' => $data['boq_id'],
             'quantity' => $data['quantity'],
             'budgetory_price' => $data['budgetory_price'],
             'size' => $data['size'],
             'unit' => $data['unit'],
             'custom_material_specs' => $data['custom_material_specs'],
              ]
        );
        return;
    }

    public function updateSubRecord($data){
        DB::table('boq_sub_materials')
            ->where('id', $data['id'])
            ->update([
                'quantity' => $data['quantity'],
                'budgetory_price' => $data['budgetory_price'],
                'size' => $data['size'],
                'unit' => $data['unit'],
                'custom_material_specs' => $data['custom_material_specs']
                ]);
        return;
    }

    public function getSubBoqRecord($id){
        $data   =   DB::table('boq_sub_materials')
            ->where('id', '=', $id)->get();
        return $data;
    }

    public function removeSubBoq($id)
    {
        DB::table('boq_sub_materials')->where('id', '=', $id)->delete();
    }
    public function removeBoq($id)
    {
        DB::table('boq_sub_materials')->where('boq_id', '=', $id)->delete();
        DB::table('material_inquiry')->where('boq_id', '=', $id)->delete();
        DB::table('supplier_proposal')->where('boq_id', '=', $id)->delete();
        DB::table('boq')->where('id', '=', $id)->delete();
    }
}
