<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class MaterialInquiry extends Model
{
    public function addRecord($data){
        DB::beginTransaction();

        try {
            DB::table('material_inquiry')->insert(
                [
                    'boq_id'        =>  $data['boq_id'],
                    'date'          =>  $data['date'],
                    'close_date'    =>  $data['close_date'],
                    'description'   =>  $data['description'],
                    'is_approved'   =>  '0'
                ]
            );

            DB::table('boq')
                ->where('id', $data['boq_id'])
                ->update(['status' => '2' , 'inquiry_is_created'=>'1']);
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
        }

    }

    public function getRecords(){
        $data = DB::table('material_inquiry')
            ->join('boq', 'material_inquiry.boq_id', '=', 'boq.id')
            ->join('sub_work_zone', 'boq.sub_work_zone_id', '=', 'sub_work_zone.id')
            ->join('sub_gml', 'boq.sub_gml_id', '=', 'sub_gml.id')
            ->select('material_inquiry.*','sub_work_zone.title as wztitle', 'sub_gml.title as gmltitle')
            ->where('material_inquiry.is_approved', '=', '1')
            ->where('material_inquiry.is_closed', '=', '0')
            ->orderBy('id', 'desc')->get();;
        return $data;
    }

    public function getClosedInquiry(){
        $data = DB::table('material_inquiry')
            ->join('boq', 'material_inquiry.boq_id', '=', 'boq.id')
            ->join('sub_work_zone', 'boq.sub_work_zone_id', '=', 'sub_work_zone.id')
            ->join('sub_gml', 'boq.sub_gml_id', '=', 'sub_gml.id')
            ->select('material_inquiry.*','sub_work_zone.title as wztitle', 'sub_gml.title as gmltitle')
            ->where('material_inquiry.is_approved', '=', '1')
            ->where('material_inquiry.is_closed', '=', '1')
            ->orderBy('id', 'desc')->get();
        return $data;
    }

    public function getPendingInquiry(){
        $data = DB::table('material_inquiry')
            ->join('boq', 'material_inquiry.boq_id', '=', 'boq.id')
            ->join('sub_work_zone', 'boq.sub_work_zone_id', '=', 'sub_work_zone.id')
            ->join('sub_gml', 'boq.sub_gml_id', '=', 'sub_gml.id')
            ->select('material_inquiry.*','sub_work_zone.title as wztitle', 'sub_gml.title as gmltitle')
            ->where('material_inquiry.is_approved', '=', '0')
            ->orderBy('id', 'desc')->get();
        return $data;
    }


    public function approveInquiry($id){
        DB::table('material_inquiry')->where('id', $id)->update(['is_approved' => '1']);
    }

    public function getSupplierProposals($id)
    {
        $data = DB::table('supplier_proposal')
            ->join('users', 'supplier_proposal.supplier_id', '=', 'users.id')
            ->select('supplier_proposal.*','users.name as name','users.email as email')
            ->where('supplier_proposal.material_inquiry_id', '=', $id)->get();

        $result = array();
        if(count($data) > 0)
        {

            foreach ($data as $k => $val)
            {
                $result[$k] =  json_decode(json_encode($data[$k]), True);
                $query      =   DB::table('supplier_proposal_details');
                $query->select(DB::raw("SUM(price) as Total"));
                $query->where('supplier_proposal_details.propsal_id', '=', $val->id);
                $price      =   $query->get();


                $query2      =   DB::table('boq_sub_materials');
                $query2->select(DB::raw("SUM(budgetory_price) as Total"));
                $query2->where('boq_sub_materials.boq_id', '=', $val->boq_id);
                $ourprice      =   $query2->get();

                $result[$k]['supplierPrice']=$price[0]->Total;
                $result[$k]['ourPrice']=$ourprice[0]->Total;
            }
        }

        return (object) $result;
    }

    public function getConsideredItems($id)
    {
        $data = DB::table('supplier_proposal')
            ->join('users', 'supplier_proposal.supplier_id', '=', 'users.id')
            ->select('supplier_proposal.*','users.name as name','users.email as email')
            ->where('supplier_proposal.material_inquiry_id', '=', $id)
            ->where('supplier_proposal.consider', '=', 1)
            ->orderBy('id', 'desc')->get();

        $result = array();
        if(count($data) > 0)
        {

            foreach ($data as $k => $val)
            {
                $result[$k] =  json_decode(json_encode($data[$k]), True);
                $query      =   DB::table('supplier_proposal_details');
                $query->select(DB::raw("SUM(price) as Total"));
                $query->where('supplier_proposal_details.propsal_id', '=', $val->id);
                $price      =   $query->get();


                $query2      =   DB::table('boq_sub_materials');
                $query2->select(DB::raw("SUM(budgetory_price) as Total"));
                $query2->where('boq_sub_materials.boq_id', '=', $val->boq_id);
                $ourprice      =   $query2->get();

                $result[$k]['supplierPrice']=$price[0]->Total;
                $result[$k]['ourPrice']=$ourprice[0]->Total;
            }
        }

        return (object) $result;
    }



    public function considerItem($id){
        DB::table('supplier_proposal')
            ->where('id', $id)
            ->update(['consider' => 1]);
    }

    public function proposalDetails($id){
        $data = DB::table('supplier_proposal_details')
            ->join('boq_sub_materials', 'supplier_proposal_details.sub_materials_id', '=', 'boq_sub_materials.id')
            ->where('supplier_proposal_details.propsal_id', '=', $id)
            ->get();
        return $data;
    }
    public function approveProposal($id){
        DB::table('supplier_proposal')
            ->join('material_inquiry', 'supplier_proposal.material_inquiry_id', '=', 'material_inquiry.id')
            ->where('supplier_proposal.id','=', $id)
            ->update(['supplier_proposal.is_accepted' => 1,'material_inquiry.is_closed' => 1]);
        return;
    }

    public function getAcceptedProposal($id){
        $data = DB::table('supplier_proposal')
            ->join('users', 'supplier_proposal.supplier_id', '=', 'users.id')
            ->join('boq', 'supplier_proposal.boq_id', '=', 'boq.id')
            ->join('sub_gml', 'boq.sub_gml_id', '=', 'sub_gml.id')
            ->select('supplier_proposal.*','users.name as name','users.email as email','users.email as email','sub_gml.title')
            ->where('supplier_proposal.material_inquiry_id', '=', $id)
            ->where('supplier_proposal.is_accepted', '=', 1)
            ->get();

            $query      =   DB::table('supplier_proposal_details');
            $query->select(DB::raw("SUM(price) as Total"));
            $query->where('supplier_proposal_details.propsal_id', '=', $data[0]->id);
            $price      =   $query->get();

            $query      =   DB::table('supplier_agreement');
            $query->where('supplier_agreement.proposal_id', '=', $data[0]->id);
            $agreementData  =   $query->get();

        $data[0]->price     =   $price[0]->Total;
        $data[0]->agreement =   $agreementData;
        return $data;
    }

    public function getSupplierId($id){
        $data = DB::table('supplier_proposal')
            ->join('boq', 'supplier_proposal.boq_id', '=', 'boq.id')
            ->select('supplier_proposal.supplier_id','boq.sub_gml_id')
            ->where('supplier_proposal.id', '=', $id)->get();
        return $data;
    }

    public function addAgreement($data){
        DB::table('supplier_agreement')->insert(
            [
                'proposal_id'           =>  $data['proposal_id'],
                'supplier_id'           =>  $data['supplier_id'],
                'sub_gml_id'            =>  $data['sub_gml_id'],
                'supplier_code'         =>  $data['supplier_code'],
                'delivery_agreement'    =>  $data['delivery_agreement'],
                'payment_terms'         =>  $data['payment_terms'],
                'final_price'           =>  $data['final_price'],
                'approve_date'          =>  $data['date'],
            ]
        );
        return;
    }

    public function approveAgreement($id){
        DB::table('supplier_agreement')
            ->where('proposal_id', $id)
            ->update(['is_approved' => '1']);
        return;
    }

    public function getAgreement($id){
        $data = DB::table('supplier_agreement')
            ->join('sub_gml', 'supplier_agreement.sub_gml_id', '=', 'sub_gml.id')
            ->where('proposal_id', $id)
            ->get();
        return $data;
    }

    public function getDeclines($id){
        $data = DB::table('supplier_decline')
            ->join('users', 'supplier_decline.supplier_id', '=', 'users.id')
            ->where('supplier_decline.material_inquiry_id', $id)
            ->get();
        return $data;
    }

}
