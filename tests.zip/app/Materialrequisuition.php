<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Materialrequisuition extends Model
{
    public function addRequsisition($data){
        DB::table('material_requisition')->insert(
            [
                'sub_boq_id' => $data['sub_boq_id'],
                'delivery_date' => $data['delivery_date'],
                'complete_date' => $data['complete_date'],
                'is_approved' => 0
            ]
        );
    }

    public function getCartITems($is_approved = 0,$checkout = 0,$is_approved_req = 0,$is_approved_lpo = 0,$is_awaiting = 0,$is_delivered = 0){
        $data = DB::table('material_requisition')
            ->join('boq_sub_materials', 'material_requisition.sub_boq_id', '=', 'boq_sub_materials.id')
            ->join('boq', 'boq_sub_materials.boq_id', '=', 'boq.id')
            ->join('sub_work_zone', 'boq.sub_work_zone_id', '=', 'sub_work_zone.id')
            ->join('sub_gml', 'boq.sub_gml_id', '=', 'sub_gml.id')
            ->select(
                    'material_requisition.*',
                    'sub_work_zone.title as workzone' ,
                    'sub_gml.title as gml',
                    'boq_sub_materials.quantity',
                    'boq_sub_materials.size',
                    'boq_sub_materials.unit'
                    )
            ->where('material_requisition.is_approved', '=', $is_approved)
            ->where('material_requisition.checkout', '=', $checkout)
            ->where('material_requisition.is_approved_req', '=', $is_approved_req)
            ->where('material_requisition.is_approved_lpo', '=', $is_approved_lpo)
            ->where('material_requisition.is_awaiting', '=', $is_awaiting)
            ->where('material_requisition.is_delivered', '=', $is_delivered)
            ->get();

        return $data;
    }

    public function approvePending($id){
        DB::table('material_requisition')
            ->where('id', $id)
            ->update(['is_approved' => 1]);
    }
    public function approveReqPending($id){
        DB::table('material_requisition')
            ->where('id', $id)
            ->update(['is_approved_req' => 1]);
    }
    public function approveLpoPending($id){
        DB::table('material_requisition')
            ->where('id', $id)
            ->update(['is_approved_lpo' => 1]);
    }
    public function markasDelivered($id){
        DB::table('material_requisition')
            ->where('id', $id)
            ->update(['is_awaiting' => 1]);
    }
    public function markaspaid($id){
        DB::table('material_requisition')
            ->where('id', $id)
            ->update(['is_delivered' => 1]);
    }
    public function checkOut($id){
        DB::table('material_requisition')
            ->where('id', $id)
            ->update(['checkout' => 1]);
    }
}

