@extends('layouts.master')

@section('content')
<?php   $inquiryIsCreated   =   0; ?>
    <ul class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">BOQ</a></li>
        <li class="active">BOQ Sub Materials</li>
    </ul>
    <div class="page-title">
        <h2>BOQ Sub Materials</h2>
    </div>
    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">
        <div class="row">
            <div class="col-md-12">
                <div style="padding:10px">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            @if(isset($data[0]->inquiry_is_created) && $data[0]->inquiry_is_created ==1)
                            <!-- do nothing here -->
                            @else
                                <a href="{{asset('boq/addboqsub/'.$id)}}">
                                    <button class="btn btn-primary btn-condensed  pull-right">
                                        <span class="fa fa-plus"></span>
                                        Add Sub Material
                                    </button>
                                </a>
                            @endif
                        </div>
                        <br />
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="">
                                        <div class="panel-heading">
                                            <h3 class="panel-title">BOQ Items List</h3>
                                        </div>
                                        <div class="panel-body panel-body-table">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped table-actions" id="workzoneList" style="border:10px solid whitesmoke">
                                                    <tr>
                                                        <th class="listHeader" width="200px">
                                                            Quantity
                                                        </th>
                                                        <th class="listHeader" width="100px">
                                                            Size
                                                        </th>
                                                        <th class="listHeader" width="100px">
                                                            Unit
                                                        </th>
                                                        <th class="listHeader" width="200px">
                                                            Custom Material Specs
                                                        </th>
                                                        <th class="listHeader" width="120">Actions</th>
                                                    </tr>
                                                    @foreach($data as $k => $val)
                                                        <?php $inquiryIsCreated = intval($val->inquiry_is_created)?>
                                                        <?php $status = intval($val->status)?>
                                                        <tr class="subMatItems">
                                                            <td>
                                                                <strong>
                                                                    {{$val->quantity}}
                                                                </strong>
                                                            </td>
                                                            <td>
                                                                {{$val->size}}
                                                            </td>
                                                            <td>
                                                                {{$val->unit}}
                                                            </td>
                                                            <td>
                                                                {{$val->custom_material_specs}}
                                                            </td>
                                                            <td>
                                                                @if($inquiryIsCreated == 0)
                                                                    <a href="{{asset('boq/addboqsub/'.$val->boq_id.'/'.$val->id)}}" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>
                                                                    <button class="btn btn-danger btn-rounded btn-condensed btn-sm" onclick="delete_row('{{$val->id}}');"><span class="fa fa-times"></span></button>
                                                                @endif
                                                                @if($val->status == 3)
                                                                    <a href="{{asset('materialrequisition/add/'.$val->id)}}" class="btn btn-info" >Create Requisition</a>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </table>
                                            </div>
                                        </div>
                                        <div class="panel-footer">
                                            @if(count($data) > 0)
                                                @if($inquiryIsCreated == 0)
                                                    <a href="{{asset('materialinquiry/add/'.$id)}}"class="btn btn-success  pull-right" style="width: 150px;padding:10px;">Create Inquiry</a>
                                                 @elseif($status != 3)
                                                    <div class="alert alert-danger" style="text-align: center">The Inquiry Currently under procurement </div>
                                                 @endif
                                            @else
                                                <div class="alert alert-danger" style="text-align: center">If You Want to Create Inquiry You Should add BOQ Sub Materials First</div>
                                            @endif

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="{{ asset('js/BOQ/main.js') }}"></script>
@endsection
