<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Scl extends Model
{
    public function fetchAll($search = null){
        $q  =   DB::table('scl');

        if(isset($search['type']))
        {
            if($search['type'] == 'title'){
                $q->where('title','like','%'.$search['value'].'%');
            }elseif ($search['type'] == 'desc'){
                $q->where('description','like','%'.$search['value'].'%');
            }else{
                $q->where('title','like','%'.$search['value'].'%');
                $q->orWhere('description','like','%'.$search['value'].'%');
            }
        }

        $data   =   $q->orderBy('id', 'desc')->paginate(5);
        return $data;
    }

    public function allScl(){
        $data  =   DB::table('scl')->orderBy('id', 'desc')->get();
        return $data;
    }

    public function getSub($search = null){
        $q  =   DB::table('sub_scl');

        $value  =   $search['value'];
        if(isset($search['type']))
        {
            if($search['type'] == 'title'){
                $q->where('title','like','%'.$value.'%');
            }elseif ($search['type'] == 'desc'){
                $q->where('description','like','%'.$value.'%');
            }else{
                $q->where(function($query )use ($value)
                {
                    $query->where('title', 'like', '%' . $value . '%')
                        ->orWhere('description', 'like', '%' . $value . '%');
                });
            }
        }

        $q->where('scl_id', '=', $search['id']);
        $q->where('is_approved', '=', 1);

        $data   =   $q->orderBy('id', 'desc')->paginate(5);
        return $data;
    }

    public function allSub($id){
        $data =   DB::table('sub_scl')->orderBy('id', 'desc')->where('scl_id', '=', $id)->get();
        return $data;
    }


    public function addRecord($data){
        DB::table('scl')->insert(
            ['title' => $data['title'], 'description' => $data['desc']]
        );
    }

    public function searchScl($data){

        $type   =   $data['type'];

        if(trim($type) == 'title'){
            $result = DB::table('scl')->where('title', 'like', '%'.$data['search'].'%')->orderBy('id', 'desc')->get();
        }elseif (trim($type) == 'desc')
        {
            $result = DB::table('scl')->where('description', 'like', '%'.$data['search'].'%')->orderBy('id', 'desc')->get();
        }else{
            $result = DB::table('scl')
                ->where('title', 'like', '%'.$data['search'].'%')
                ->orWhere('description', 'like', '%'.$data['search'].'%')
                ->orderBy('id', 'desc')
                ->get();
        }
        return $result;
    }

    public function searchSubScl($data){

        $type   =   $data['type'];

        if(trim($type) == 'title'){
            $result = DB::table('sub_scl')->where('scl_id', '=', $data['scl_id'])->where('title', 'like', '%'.$data['search'].'%')->where('is_approved', '=', 1)->orderBy('id', 'desc')->get();
        }elseif (trim($type) == 'desc')
        {
            $result = DB::table('sub_scl')->where('scl_id', '=', $data['scl_id'])->where('description', 'like', '%'.$data['search'].'%')->where('is_approved', '=', 1)->orderBy('id', 'desc')->get();
        }else{
            $result = DB::table('sub_scl')
                ->where('scl_id', '=', $data['scl_id'])
                ->where(function($query )use ($data)
                {
                    $query->where('title', 'like', '%' . $data['search'] . '%')
                        ->orWhere('description', 'like', '%' . $data['search'] . '%');
                })
                ->where('is_approved', '=', 1)
                ->orderBy('id', 'desc')
                ->get();
        }
        return $result;
    }



    public function getRecord($id){
        $data = DB::table('scl')->where('id', '=', $id)->get();

        return $data;
    }

    public function getSubRecord($id){
        $data = DB::table('sub_scl')->where('id', '=', $id)->get();

        return $data;
    }

    public function updateRecord($data){
        DB::table('scl')
            ->where('id', $data['id'])
            ->update(['title' => $data['title'] , 'description'=>$data['desc']]);
    }

    public function removeRec($id)
    {
        DB::table('scl')->where('id', '=', $id)->delete();
    }

    public function checkSclIsUsed($id){
        $count  =   DB::table('sub_scl')->where('scl_id','=',$id)->count();
        return $count;
    }

    public function checkSubGmlIsUsed($id){
        $count  =   DB::table('scr')->where('sub_scl_id','=',$id)->count();
        return $count;
    }

    public function addSubRecord($data){
        DB::table('sub_scl')->insert(
            ['scl_id' => $data['sclId'],'title' => $data['title'], 'description' => $data['desc'],'is_approved'=>'0']
        );
    }

    public function updateSubRecord($data){
        DB::table('sub_scl')
            ->where('id', $data['id'])
            ->update(['title' => $data['title'] , 'description'=>$data['desc']]);
    }


    public function removeSubScl($id)
    {
        DB::table('sub_scl')->where('id', '=', $id)->delete();
        DB::table('subcontractor_category')->where('sub_category_id', '=', $id)->delete();
    }

    public function getPending($id){
        if(isset($id) && $id > 0)
        {
            $data   =   DB::table('sub_scl')->where('is_approved', '=', 0)->where('scl_id', '=', $id)->orderBy('id', 'desc')->get();
        }else{
            $data   =   DB::table('sub_scl')->where('is_approved', '=', 0)->orderBy('id', 'desc')->get();
        }
        return $data;
    }

    public function approvePending($id){
        DB::table('sub_scl')
            ->where('id', $id)
            ->update(['is_approved' =>1]);
    }
}
