<?php

namespace App\Http\Controllers;

use App\important\checkAuth;
use App\important\checkMenu;
use App\MaterialInquiry;
use App\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class MaterialinquiryController extends Controller
{
    private $menu;
    private $checkAuth;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->menu         =   new checkMenu();
        $this->checkAuth    =   new checkAuth();
    }
    public function show()
    {
        $authMTinq        =   $this->checkAuth->checkMTInquiry();
        $menuData   =   $this->menu->Menu('workzone','materialInq' ,'showMtinq');
        if($authMTinq->can_show)
        {
            $MTinquiry      =       new MaterialInquiry();
            $data           =       $MTinquiry->getRecords();
            return view('MTInquiry.show')->with('menu', $menuData)->with('data',$data);
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function closed()
    {
        $authMTinq        =   $this->checkAuth->checkMTInquiry();
        $menuData   =   $this->menu->Menu('workzone','materialInq' , 'closeMtinq');
        if($authMTinq->can_show)
        {
            $MTinquiry      =       new MaterialInquiry();
            $data           =       $MTinquiry->getClosedInquiry();
            return view('MTInquiry.closed')->with('menu', $menuData)->with('data',$data);
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function add(Request $request){
        $authMTInquiry  =   $this->checkAuth->checkMTInquiry();
        $menuData       =   $this->menu->Menu('workzone','materialInq');
        if($authMTInquiry->can_edit) {
                return view('MTInquiry.add')->with('menu', $menuData)->with('boq_id',$request->id);
        }
        else{
            return view('home')->with('menu', $menuData);
        }
    }



    public function addmtinquiry(Request $request){
        $menuData   =   $this->menu->Menu('workzone','materialInq');
        $this->validate($request, [
            'date'             => 'required|date|date_format:Y-m-d|after:yesterday',
            'closeDate'        => 'required|date|date_format:Y-m-d|after:date'
        ]);

        $authMTinq        =   $this->checkAuth->checkMTInquiry();
        if($authMTinq->can_edit) {
            $data   =   array();
            $data['boq_id']         =   intval($request->boq_id);
            $data['date']           =   date($request->date);
            $data['close_date']     =   date($request->closeDate);
            $data['description']    =   $request->description;


            $MTinquiry    =   new MaterialInquiry();
            $MTinquiry->addRecord($data);

            return redirect('boq/showsubboq/'.$request->boq_id)->with('menu', $menuData);

        }
        else{
            return view('home')->with('menu', $menuData);
        }
    }

    public function pending(){
        $authMTinq        =   $this->checkAuth->checkMTInquiry();
        $menuData   =   $this->menu->Menu('workzone','materialInq','pendingMtinq');
        if($authMTinq->can_approve)
        {
            $MTinquiry      =       new MaterialInquiry();
            $data           =       $MTinquiry->getPendingInquiry();
            return view('MTInquiry.pending')->with('menu', $menuData)->with('data',$data);
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function approve(Request $request){
        $authMTinq        =   $this->checkAuth->checkMTInquiry();
        if($authMTinq->can_approve)
        {
            $MTinquiry      =       new MaterialInquiry();
            $data           =       $MTinquiry->approveInquiry($request->id);
            return back();
        }
        else{
            redirect(asset('home'));
        }
    }

    public function suplierProposal(Request $request)
    {
        $authMTinq = $this->checkAuth->checkMTInquiry();
        $menuData = $this->menu->Menu('workzone', 'materialInq');
        if ($authMTinq->can_show) {
            $id   =   $request->id;
            $MTinquiry = new MaterialInquiry();
            $data = $MTinquiry->getSupplierProposals($id);

            return view('MTInquiry.suppliersProposal')->with('menu', $menuData)->with('data', $data);
        } else {
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function proposalDetails(Request $request)
    {
        $menuData = $this->menu->Menu('workzone', 'materialInq');
        $authMTinq = $this->checkAuth->checkMTInquiry();
        if ($authMTinq->can_show) {
            $materialsInq   =   new MaterialInquiry();
            if(intval($request->id) > 0){
                $proposalDetails   =   $materialsInq->proposalDetails($request->id);
                return view('MTInquiry.proposalDetails')->with('menu', $menuData)->with('data', $proposalDetails);
            }
        }
        return Redirect::back();

    }
    public function considerItem(Request $request){
        $authMTinq = $this->checkAuth->checkMTInquiry();
        if ($authMTinq->can_show) {
            $materialsInq   =   new MaterialInquiry();
            if(intval($request->id) > 0){
                $considerItem   =   $materialsInq->considerItem($request->id);
            }
        }
        return Redirect::back();
    }

    public function consideredItems(Request $request){
        $authMTinq = $this->checkAuth->checkMTInquiry();
        $menuData = $this->menu->Menu('workzone', 'materialInq');
        if ($authMTinq->can_show) {
            $id   =   $request->id;
            $MTinquiry = new MaterialInquiry();
            $data = $MTinquiry->getConsideredItems($id);

            return view('MTInquiry.consideredSuppliers')->with('menu', $menuData)->with('data', $data);
        } else {
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function approveProposal(Request $request){
        $authMTinq = $this->checkAuth->checkMTInquiry();
        if ($authMTinq->can_show) {
            $materialsInq   =   new MaterialInquiry();
            if(intval($request->id) > 0){
                $considerItem   =   $materialsInq->approveProposal($request->id);
            }
        }
        return redirect()->action('MaterialinquiryController@closed');
    }


    public function showAccepted(Request $request){
        $authMTinq = $this->checkAuth->checkMTInquiry();
        $menuData = $this->menu->Menu('workzone', 'materialInq');
        if ($authMTinq->can_show) {
            $materialsInq   =   new MaterialInquiry();
            $data    =   $materialsInq->getAcceptedProposal($request->id);
            return view('MTInquiry.showAccepted')->with('menu', $menuData)->with('data', $data);
        }
        return redirect()->action('MaterialinquiryController@closed');
    }





    public function createAgreement(Request $request){
        $id =   $request->id;
        $authMTinq = $this->checkAuth->checkMTInquiry();
        $menuData = $this->menu->Menu('workzone', 'materialInq');
        if ($authMTinq->can_edit) {
            return view('MTInquiry.createAgreement')->with('menu', $menuData)->with('id', $id);
        }
        return Redirect::back();
    }


    /**
     * @param Request $request
     */
    public function approveAgreement(Request $request){
        $authMTinq = $this->checkAuth->checkMTInquiry();
        if ($authMTinq->can_approve) {
            $materialsInq   =   new MaterialInquiry();
            $supplier_id    =   $materialsInq->approveAgreement($request->id);
            return Redirect::back();
        }
    }

    public function addAgreement(Request $request){
        $this->validate($request, [
            'proposal_id' => 'required|not_in:0',
            'supplier_code' => 'required',
            'delivery_agreement' => 'required',
            'payment_terms' => 'required',
            'final_price' => 'required',
        ]);
        $authMTinq = $this->checkAuth->checkMTInquiry();
        if ($authMTinq->can_edit) {
            $materialsInq   =   new MaterialInquiry();
            $supplier_id    =   $materialsInq->getSupplierId($request->proposal_id);

            $data['proposal_id']        =  $request->proposal_id ;
            $data['supplier_id']        =  $supplier_id[0]->supplier_id;
            $data['sub_gml_id']         =  $supplier_id[0]->sub_gml_id;
            $data['supplier_code']      =  $request->supplier_code ;
            $data['delivery_agreement'] =  $request->delivery_agreement ;
            $data['payment_terms']      =  $request->payment_terms ;
            $data['final_price']        =  $request->final_price ;
            $data['date']               =  date("Y/m/d");

            $materialsInq->addAgreement($data);

        }
        $menuData = $this->menu->Menu('workzone', 'materialInq');
        return redirect()->action('MaterialinquiryController@closed');
    }

    public function showAgreement(Request $request){
        $authMTinq = $this->checkAuth->checkMTInquiry();
        if ($authMTinq->can_show) {
            $menuData = $this->menu->Menu('workzone', 'materialInq');
            $materialsInq   =   new MaterialInquiry();
            $data    =   $materialsInq->getAgreement($request->id);
            return view('MTInquiry.showAgreement')->with('menu', $menuData)->with('data', $data[0]);
        }
    }

    public function decline(Request $request){
        $authMTinq = $this->checkAuth->checkMTInquiry();
        if ($authMTinq->can_show) {
            $materialsInq   =   new MaterialInquiry();
            $data    =   $materialsInq->getDeclines($request->id);

            $menuData   =   $this->menu->Menu('workzone','materialInq' ,'showMtinq');
            return view('MTInquiry.showDecline')->with('menu', $menuData)->with('data', $data);
        }
        return Redirect::back();
    }

}
