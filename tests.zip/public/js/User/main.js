$(function() {
    $('.select2').select2();
});

function serachUser(){
    var type    =   $("#searchType").val();
    var word    =   $("#searchGml").val();

    $.ajax({
        type: "GET",
        url: 'gmlSearch',
        data:{'type':type,'search':word},
        success: function(data) {
            var obj = JSON.parse(data);
            var table=$('#gmlList');
            table.find("tr:gt(0)").remove();
            $.each(obj , function( index, value ) {
                table.append('<tr  class="subMatItems" onclick="subMaterials('+value.id+')">'+
                    '<td><strong>'+value.title+'</strong></td>' +
                    '<td>'+value.description+'</td>' +
                    '<td><a href="pendingSub/'+value.id+'" class="btn btn-info" style="width:120px">Pending</a></td>' +
                    '<td><a href="add/'+value.id+'" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>' +
                    '<button class="btn btn-danger btn-rounded btn-condensed btn-sm" onclick="delete_row('+value.id+');"><span class="fa fa-times"></span></button>' +
                    '</td>' +
                    '</tr>');
            });
        }
    });

}

function saveTheRules(){
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    swal({
        title: "Are you sure?",
        text: "Are You sure you Want Update The Rules!",
        icon: "warning",
        buttons: true,
        dangerMode: false,
    })
        .then((willDelete) => {
            if (willDelete) {

                var id      = $('#screen').val();
                var screen_id   = $('.screen_id');
                data = [];
                $.each(screen_id ,function (index ,value) {
                    $object =   {};
                    $('#can_show'+value.value).is(':checked')       ? $object.can_show = 1 : $object.can_show =0 ;
                    $('#can_edit'+value.value).is(':checked')       ? $object.can_edit = 1 : $object.can_edit =0 ;
                    $('#can_approve'+value.value).is(':checked')    ? $object.can_approve = 1 : $object.can_approve =0 ;
                    $('#can_approve2'+value.value).is(':checked')   ? $object.can_approve2 = 1 : $object.can_approve2 =0 ;
                    $('#can_approve3'+value.value).is(':checked')   ? $object.can_approve3 = 1 : $object.can_approve3 =0 ;
                    $object.screen          = value.value;
                    data.push($object);
                });

                $.ajax({
                    type: "POST",
                    url: '../setTheRules',
                    data:{_token: CSRF_TOKEN,'id':id,'data':data},
                    success: function(data) {
                        window.location = "/users/showUsers";
                    }
                });
            }
        });
}
function saveThePosition(){
    position_name   =   $("#position_name").val();
    var checkName   =   position_name.replace(/ /g,'');
    position_id   =   $("#position_id").val();
    if(checkName == ""){
        $("#position_name").css('border','1px solid red');
        swal({
            title: "Stop!!!",
            text: "You should Enter The Position Name",
            icon: "warning",
            buttons: false,
            dangerMode: true,
        })
        return;
    }

    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    swal({
        title: "Are you sure?",
        text: "Are You sure you Want Update The Rules!",
        icon: "warning",
        buttons: true,
        dangerMode: false,
    })
        .then((willDelete) => {
            if (willDelete) {
                var id      = $('#screen').val();
                var screen_id   = $('.screen_id');
                position    = position_name;
                data = [];
                $.each(screen_id ,function (index ,value) {
                    $object =   {};
                    $('#can_show'+value.value).is(':checked')       ? $object.can_show = 1 : $object.can_show =0 ;
                    $('#can_edit'+value.value).is(':checked')       ? $object.can_edit = 1 : $object.can_edit =0 ;
                    $('#can_approve'+value.value).is(':checked')    ? $object.can_approve = 1 : $object.can_approve =0 ;
                    $('#can_approve2'+value.value).is(':checked')   ? $object.can_approve2 = 1 : $object.can_approve2 =0 ;
                    $('#can_approve3'+value.value).is(':checked')   ? $object.can_approve3 = 1 : $object.can_approve3 =0 ;
                    $object.screen          = value.value;
                    data.push($object);
                });
                $.ajax({
                    type: "POST",
                    url: '/users/setThePositions',
                    data:{_token: CSRF_TOKEN,'title':position,'data':data,'id':position_id},
                    success: function(data) {
                       window.location = "/users/showPositions";
                    }
                });
            }
        });
}

function delete_row(id){
    swal({
        title: "Are you sure?",
        text: "Are You sure you Want to Delete this record!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "GET",
                    url: 'removegml',
                    data:{'id':id},
                    success: function(data) {
                        location.reload();
                    }
                });
            }
        });

}
function delete_sub(id){
    swal({
        title: "Are you sure?",
        text: "Are You sure you Want to Delete this record!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "GET",
                    url: '../removesubgml',
                    data:{'id':id},
                    success: function(data) {
                        location.reload();
                    }
                });
            }
        });

}


function userProfile(id){
    window.location = "/users/showuserprofiel/"+id;
}