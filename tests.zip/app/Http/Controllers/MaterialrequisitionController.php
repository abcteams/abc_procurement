<?php

namespace App\Http\Controllers;

use App\important\checkAuth;
use App\important\checkMenu;
use App\Materialrequisuition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class MaterialrequisitionController extends Controller
{
    public $UserName;
    private $menu;
    private $checkAuth;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->UserName     =   "mekdad";
        $this->middleware('auth');
        $this->menu         =   new checkMenu();
        $this->checkAuth    =   new checkAuth();
    }


    public function add(Request $request){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        $menuData   =   $this->menu->Menu('workzone','');
        if($authMtRequisition->can_edit) {

            return view('MTRequisition.add')->with('menu',$menuData)->with('id',$request->id);
        }
        else{
            return redirect()->action('HomeController@index');
        }
    }
    public function addrequisition(Request $request){
        print_r($request->post());die();
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        $menuData   =   $this->menu->Menu('workzone','');
        if($authMtRequisition->can_edit) {

            $this->validate($request, [
                'sub_boq_id'        => 'required',
                'quantity'          => 'required',
                'delivery_date'     => 'required|date|date_format:Y-m-d|after:yesterday',
                'complete_date'     => 'required|date|date_format:Y-m-d|after:delivery_date'
            ]);

            $data['sub_boq_id']     =   $request->sub_boq_id;
            $data['quantity']       =   $request->quantity;
            $data['delivery_date']  =   $request->delivery_date;
            $data['complete_date']  =   $request->complete_date;
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->addRequsisition($data);

            return redirect()->action('HomeController@index');
        }
        else{
            return redirect()->action('HomeController@index');
        }
    }

    public function show(){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        $menuData   =   $this->menu->Menu('Cart','showCart');
        if($authMtRequisition->can_show) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->getCartITems(1);
            return view('MTRequisition.show')->with('menu',$menuData)->with('data',$result);
        }else{
            return redirect()->action('HomeController@index');
        }
    }

    public function approvePending(Request $request){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        if($authMtRequisition->can_approve) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->approvePending($request->id);
            return redirect()->action('MaterialrequisitionController@pending');
        }else{
            return redirect()->action('HomeController@index');
        }
    }
    public function pending(){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        $menuData   =   $this->menu->Menu('Cart','pendingCart');
        if($authMtRequisition->can_approve) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->getCartITems(0);
            return view('MTRequisition.pending')->with('menu',$menuData)->with('data',$result);
        }else{
            return redirect()->action('HomeController@index');
        }
    }
    public function checkout(Request $request){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        if($authMtRequisition->can_edit) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->checkout($request->id);
            return redirect()->action('MaterialrequisitionController@show');
        }else{
            return redirect()->action('HomeController@index');
        }
    }

    public function reqPending(){
        $authMtRequisition2        =   $this->checkAuth->checkMTRequisition2();
        $menuData   =   $this->menu->Menu('workzone','materialReq','pendingMtReq');
        if($authMtRequisition2->can_show) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->getCartITems(1,1);
            return view('MTRequisition.reqpending')->with('menu',$menuData)->with('data',$result);
        }else{
            return redirect()->action('HomeController@index');
        }
    }

    public function approveReqPending(Request $request){
        $authMtRequisition2        =   $this->checkAuth->checkMTRequisition2();
        if($authMtRequisition2->can_show) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->approveReqPending($request->id);
            return redirect()->action('MaterialrequisitionController@reqPending');
        }else{
            return redirect()->action('HomeController@index');
        }
    }
    public function approveLpoPending(Request $request){
        $authMtRequisition2        =   $this->checkAuth->checkMTRequisition2();
        if($authMtRequisition2->can_edit) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->approveLpoPending($request->id);
            return redirect()->action('MaterialrequisitionController@lpoPending');
        }else{
            return redirect()->action('HomeController@index');
        }
    }
    public function markasDelivered(Request $request){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        if($authMtRequisition->can_edit) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->markasDelivered($request->id);
            return redirect()->action('MaterialrequisitionController@awaiting');
        }else{
            return redirect()->action('HomeController@index');
        }
    }
    public function markaspaid(Request $request){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        if($authMtRequisition->can_edit) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->markaspaid($request->id);
            return redirect()->action('MaterialrequisitionController@delivered');
        }else{
            return redirect()->action('HomeController@index');
        }
    }

    public function lpoPending(){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        $menuData   =   $this->menu->Menu('workzone','materialReq','lpoPendingMtinq');
        if($authMtRequisition->can_edit) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->getCartITems(1,1,1);
            return view('MTRequisition.lpopending')->with('menu',$menuData)->with('data',$result);
        }else{
            return redirect()->action('HomeController@index');
        }
    }
    public function awaiting(){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        $menuData   =   $this->menu->Menu('workzone','materialReq','awaitingMtinq');
        if($authMtRequisition->can_edit) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->getCartITems(1,1,1,1);
            return view('MTRequisition.awaiting')->with('menu',$menuData)->with('data',$result);
        }else{
            return redirect()->action('HomeController@index');
        }
    }
    public function delivered(){
        $authMtRequisition        =   $this->checkAuth->checkMTRequisition();
        $menuData   =   $this->menu->Menu('workzone','materialReq','deliveredMtinq');
        if($authMtRequisition->can_edit) {
            $mtRequisition  =    new Materialrequisuition();
            $result =   $mtRequisition->getCartITems(1,1,1,1,1);
            return view('MTRequisition.delivered')->with('menu',$menuData)->with('data',$result);
        }else{
            return redirect()->action('HomeController@index');
        }
    }

}
