@extends('layouts.master')
@section('content')
    <div class="page-content-wrap">
        <div class="row" style="background: none;border: 0px">
            <div class="col-md-3"></div>
            <div class="col-md-6" style="padding-top: 150px">

                <div class="form-control alert-success" style="padding: 30px;display: inline-table;" >
                    <div class="form-control alert-danger" style="padding: 50px;text-align: center;font-size: 20px;line-height: 5px;" >Wait admin To Approve you</div>
                </div>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>

@endsection
