<?php

namespace App\Http\Controllers;

use App\Boq;
use App\gml;
use App\important\checkAuth;
use App\important\checkMenu;
use Illuminate\Http\Request;

class BoqController extends Controller
{
    private $menu;
    private $checkAuth;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->menu         =   new checkMenu();
        $this->checkAuth    =   new checkAuth();
    }


    public function show(Request $request)
    {
        $menuData   =   $this->menu->Menu('workzone','');
        $authBOQ        =   $this->checkAuth->checkBOQ();
        if($authBOQ->can_show)
        {
            $search['id']       =   $request->id;
            $search['type']     =   $request->type;
            $search['value']    =   $request->value;

            $Boq    =   new Boq();
            $data   =   $Boq->fetchAll($search);

            return view('BOQ.show')->with('menu',$menuData)->with('data',$data)->with('id',$request->id)->with('auth',$authBOQ);
        }
        else{
            return redirect()->action('HomeController@index');
        }
    }

    public function add(Request $request){
        $authBOQ        =   $this->checkAuth->checkBOQ();
        $menuData   =   $this->menu->Menu('workzone','');
        if($authBOQ->can_edit) {
            $gml        =   new gml();
            $gmldata    =   $gml->fetchAll();
            if (isset($request->id) && $request->id > 0) {
                $Boq = new Boq();
                $data = $Boq->getRecord($request->id);
                return view('BOQ.add')->with('menu', $menuData)->with('theRecord', $data)->with('gml',$gmldata);
            } else {
                return view('BOQ.add')->with('menu', $menuData)->with('gml',$gmldata)->with('workzoneId',$request->workzoneId);
            }
        }
        else{
            return redirect()->action('HomeController@index');
        }
    }

    public function addboq(Request $request){
        $menuData   =   $this->menu->Menu('workzone','');
        $this->validate($request, [
            'sub_gml' => 'required|not_in:0',
        ]);

        $authBOQ        =   $this->checkAuth->checkBOQ();
        if($authBOQ->can_edit) {
            $data   =   array();
            $data['workzoneId']  =   intval($request->workzoneId);
            $data['sub_gml_id']   =   intval($request->sub_gml);

            $Boq    =   new Boq();
            if(isset($request->id )&& $request->id > 0) {
                $data['id']   =   $request->id;
                $Boq->updateRecord($data);
            }else{
                $Boq->addRecord($data);
            }
            return redirect('boq/show/'.$request->workzoneId)->with('menu', $menuData);
        }
        else{
            return redirect()->action('HomeController@index');
        }
    }

    public function getsubgmlitems(Request $request)
    {
        $gml_id =   intval($request->gml_id);
        if($gml_id > 0){
            $gml    =   new gml();
            $data   =   $gml->getSubGml($gml_id);
            die(json_encode($data));

        }else{
            die(0);
        }
    }

    public function showsubboq(Request $request){
        $menuData   =   $this->menu->Menu('workzone','');
        $authBOQ        =   $this->checkAuth->checkBOQ();
        if($authBOQ->can_show)
        {
            $Boq    =   new Boq();
            $data   =   $Boq->showsubboq($request->id);
            return view('BOQ.showsub')->with('menu', $menuData)->with('data',$data)->with('id',$request->id);
        }
        else{
            return redirect()->action('HomeController@index');
        }
    }

    public function addboqsub(Request $request){
        $menuData   =   $this->menu->Menu('workzone','materialInq');
        $authBOQ        =   $this->checkAuth->checkBOQ();
        if($authBOQ->can_edit) {
            if (isset($request->id) && $request->id > 0) {
                $Boq = new Boq();
                $data = $Boq->getSubBoqRecord($request->id);
                return view('BOQ.addboqsub')->with('mainMenu', 'workzone')->with('theRecord', $data)->with('boq_id',$request->boq_id);
            } else {
                return view('BOQ.addboqsub')->with('menu', $menuData)->with('boq_id',$request->boq_id);
            }
        }
        else{
            return redirect()->action('HomeController@index');
        }

    }

    public function addboqsubmaterilas(Request $request){
        $menuData   =   $this->menu->Menu('workzone','materialInq');
        $this->validate($request, [
            'quantity'  => 'required|not_in:0',
            'budgetory' => 'required|not_in:0',
            'size'      => 'required|not_in:0',
            'unit'      => 'required',
        ]);

        $authBOQ        =   $this->checkAuth->checkBOQ();
        if($authBOQ->can_edit) {
            $data   =   array();

            $data['boq_id']                 =   $request->boq_id;
            $data['quantity']               =   $request->quantity;
            $data['budgetory_price']        =   $request->budgetory;
            $data['size']                   =   $request->size;
            $data['unit']                   =   $request->unit;
            $data['custom_material_specs']  =   $request->material_specs;


            $Boq    =   new Boq();
            if(isset($request->id )&& $request->id > 0) {
                $data['id']   =   $request->id;
                $Boq->updateSubRecord($data);
            }else{
                $Boq->addsubRecord($data);
            }
            return redirect('boq/showsubboq/'.$request->boq_id)->with('menu', $menuData);
        }
        else{
            return redirect()->action('HomeController@index');
        }
    }

    public function removeSubBoq(Request $request){
        $authBOQ        =   $this->checkAuth->checkBOQ();
        if ($authBOQ->can_edit) {
            $Boq = new Boq();
            $Boq->removeSubBoq($request->id);
        }
        die();
    }

    public function removeBoq(Request $request){
        $authBOQ        =   $this->checkAuth->checkBOQ();
        if ($authBOQ->can_edit) {
            $Boq = new Boq();
            $Boq->removeBoq($request->id);
        }
        die();
    }

}
