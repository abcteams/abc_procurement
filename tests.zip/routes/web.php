<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});


Route::get('/login', function () {
    return view('auth/login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


/*********************** GML *************************/
Route::get('gml/show', 'GmlController@show');
Route::get('gml/add/{id?}', 'GmlController@add');
Route::post('gml/addGml', 'GmlController@addGml');
Route::get('gml/gmlSearch', 'GmlController@gmlSearch');
Route::get('gml/removegml', 'GmlController@removegml');


/*********************** Sub Gml *************************/
Route::get('gml/showsub/{id}', 'GmlController@showsub');
Route::get('gml/addsub/{gmlId}/{id?}', 'GmlController@addsub');
Route::post('gml/addsubgml', 'GmlController@addsubgml');
Route::get('gml/subGmlSearch', 'GmlController@subGmlSearch');
Route::get('gml/removesubgml', 'GmlController@removesubgml');

/*********************** pending *************************/
Route::get('gml/pendingSub/{id?}', 'GmlController@pendingSub');
Route::get('gml/approvePending/{id}', 'GmlController@approvePending');





/*********************** Scl *************************/
Route::get('scl/show', 'SclController@show');
Route::get('scl/add/{id?}', 'SclController@add');
Route::post('scl/addScl', 'SclController@addScl');
Route::get('scl/sclSearch', 'SclController@sclSearch');
Route::get('scl/removescl', 'SclController@removescl');

/*********************** Sub Scl *************************/
Route::get('scl/showsub/{id}', 'SclController@showsub');
Route::get('scl/addsub/{sclId}/{id?}', 'SclController@addsub');
Route::post('scl/addsubscl', 'SclController@addsubscl');
Route::get('scl/subSclSearch', 'SclController@subSclSearch');
Route::get('scl/removesubscl', 'SclController@removesubscl');

/*********************** pending *************************/
Route::get('scl/pendingSub/{id?}', 'SclController@pendingSub');
Route::get('scl/approvePending/{id}', 'SclController@approvePending');


/*********************** Work Zone *************************/
Route::get('workzone/show', 'WorkzoneController@show');
Route::get('workzone/add/{id?}', 'WorkzoneController@add');
Route::post('workzone/addWorkzone', 'WorkzoneController@addWorkzone');
Route::get('workzone/workzoneSearch', 'WorkzoneController@workzoneSearch');

/*********************** Sub Gml *************************/
Route::get('workzone/showsub/{id}', 'WorkzoneController@showsub');
Route::get('workzone/addsub/{workzoneId}/{id?}', 'WorkzoneController@addsub');
Route::post('workzone/addsubworkzone', 'WorkzoneController@addsubworkzone');
Route::get('workzone/serachSubZone', 'WorkzoneController@serachSubZone');
Route::get('workzone/removeWorkZone', 'WorkzoneController@removeWorkZone');
Route::get('workzone/removeSubWorkZone', 'WorkzoneController@removeSubWorkZone');






/*********************** BOQ  *************************/
Route::get('boq/show/{id}', 'BoqController@show');
Route::get('boq/add/{workzoneId}/{id?}', 'BoqController@add');
Route::get('boq/getsubgmlitems', 'BoqController@getsubgmlitems');
Route::post('boq/addboq', 'BoqController@addboq');

/*********************** SUB BOQ  *************************/
Route::get('boq/showsubboq/{id}', 'BoqController@showsubboq');
Route::get('boq/addboqsub/{boq_id}/{id?}', 'BoqController@addboqsub');
Route::post('boq/addboqsubmaterilas', 'BoqController@addboqsubmaterilas');
Route::get('boq/removeSubBoq', 'BoqController@removeSubBoq');
Route::get('boq/removeBoq', 'BoqController@removeBoq');


/********************* Material Inquiry **********************/
Route::get('materialinquiry/show', 'MaterialinquiryController@show');
Route::get('materialinquiry/closed', 'MaterialinquiryController@closed');

Route::get('materialinquiry/add/{id}', 'MaterialinquiryController@add');
Route::post('materialinquiry/addMTInquiry', 'MaterialinquiryController@addmtinquiry');

Route::get('materialinquiry/pending', 'MaterialinquiryController@pending');
Route::get('materialinquiry/approve/{id}', 'MaterialinquiryController@approve');
Route::get('materialinquiry/subcontractorProposal/{id}', 'MaterialinquiryController@subcontractorProposal');
Route::get('materialinquiry/considerItem/{id}', 'MaterialinquiryController@considerItem');
Route::get('materialinquiry/proposalDetails/{id}', 'MaterialinquiryController@proposalDetails');
Route::get('materialinquiry/consideredItems/{id}', 'MaterialinquiryController@consideredItems');
Route::get('materialinquiry/approveProposal/{id}', 'MaterialinquiryController@approveProposal');
Route::get('materialinquiry/showAccepted/{id}', 'MaterialinquiryController@showAccepted');
Route::get('materialinquiry/createAgreement/{id}', 'MaterialinquiryController@createAgreement');
Route::get('materialinquiry/approveAgreement/{id}', 'MaterialinquiryController@approveAgreement');
Route::post('materialinquiry/addAgreement', 'MaterialinquiryController@addAgreement');
Route::get('materialinquiry/showAgreement/{id}', 'MaterialinquiryController@showAgreement');
Route::get('materialinquiry/suplierProposal/{id}', 'MaterialinquiryController@suplierProposal');
Route::get('materialinquiry/decline/{id}', 'MaterialinquiryController@decline');



/********************* Suppliers **********************/
Route::get('supplier/materials', 'SupplierController@materials');
Route::get('supplier/addmaterial', 'SupplierController@addmaterial');
Route::get('supplier/getsubgmlitems', 'SupplierController@getsubgmlitems');
Route::post('supplier/addmaterialrec', 'SupplierController@addmaterialrec');

Route::get('supplier/removeMaterial', 'SupplierController@removeMaterial');
Route::get('supplier/pendinginquiry', 'SupplierController@pendinginquiry');
Route::get('supplier/proposal/{id}', 'SupplierController@proposal');
Route::get('supplier/decline/{id}', 'SupplierController@decline');
Route::post('supplier/addDecline', 'SupplierController@addDecline');

Route::post('supplier/addProposal', 'SupplierController@addProposal');
Route::get('supplier/pendingAgreement', 'SupplierController@pendingAgreement');
Route::get('supplier/accepetAgreement/{id}', 'SupplierController@accepetAgreement');
Route::get('supplier/sentProposals', 'SupplierController@sentProposals');
Route::get('supplier/myProposalDetails/{id}', 'SupplierController@myProposalDetails');
Route::get('supplier/lop', 'SupplierController@lop');





/*********************** SCR  *************************/
Route::get('scr/show/{id}', 'ScrController@show');
Route::get('scr/add/{workzoneId}/{id?}', 'ScrController@add');
Route::get('scr/getsubsclitems', 'ScrController@getsubsclitems');
Route::post('scr/addscr', 'ScrController@addscr');

/*********************** SUB SCR *************************/
Route::get('scr/showsubscr/{id}', 'ScrController@showsubscr');
Route::get('scr/addscrsub/{scr_id}/{id?}', 'ScrController@addscrsub');
Route::post('scr/addscrsubcategory', 'ScrController@addscrsubcategory');






/********************* Subcontractor Request **********************/
Route::get('subcontractorrequest/show'                  , 'SubcontractorrequestController@show');
Route::get('subcontractorrequest/closed'                , 'SubcontractorrequestController@closed');

Route::get('subcontractorrequest/add/{id}'              , 'SubcontractorrequestController@add');
Route::post('subcontractorrequest/addSCrequest'         , 'SubcontractorrequestController@addSCrequest');

Route::get('subcontractorrequest/pending'               , 'SubcontractorrequestController@pending');
Route::get('subcontractorrequest/approve/{id}'          , 'SubcontractorrequestController@approve');
Route::get('subcontractorrequest/subcontractorProposal/{id}'  , 'SubcontractorrequestController@subcontractorProposal');
Route::get('subcontractorrequest/considerItem/{id}'     , 'SubcontractorrequestController@considerItem');
Route::get('subcontractorrequest/proposalDetails/{id}'  , 'SubcontractorrequestController@proposalDetails');
Route::get('subcontractorrequest/consideredItems/{id}'  , 'SubcontractorrequestController@consideredItems');
Route::get('subcontractorrequest/approveProposal/{id}'  , 'SubcontractorrequestController@approveProposal');
Route::get('subcontractorrequest/showAccepted/{id}'     , 'SubcontractorrequestController@showAccepted');
Route::get('subcontractorrequest/createAgreement/{id}'  , 'SubcontractorrequestController@createAgreement');
Route::get('subcontractorrequest/approveAgreement/{id}' , 'SubcontractorrequestController@approveAgreement');
Route::post('subcontractorrequest/addAgreement'         , 'SubcontractorrequestController@addAgreement');
Route::get('subcontractorrequest/showAgreement/{id}'    , 'SubcontractorrequestController@showAgreement');
Route::get('subcontractorrequest/decline/{id}', 'SubcontractorrequestController@decline');




/********************* Subcontractor **********************/
Route::get('subcontractor/category', 'SubcontractorController@category');
Route::get('subcontractor/addcategory', 'SubcontractorController@addcategory');
Route::get('subcontractor/getsubsclitems', 'SubcontractorController@getsubsclitems');
Route::post('subcontractor/addcategoryrec', 'SubcontractorController@addcategoryrec');


Route::get('subcontractor/removeCategory', 'SubcontractorController@removeCategory');
Route::get('subcontractor/pendingRequest', 'SubcontractorController@pendingRequest');
Route::get('subcontractor/proposal/{id}', 'SubcontractorController@proposal');
Route::get('subcontractor/decline/{id}', 'SubcontractorController@decline');
Route::post('subcontractor/addDecline', 'SubcontractorController@addDecline');

Route::post('subcontractor/addProposal', 'SubcontractorController@addProposal');
Route::get('subcontractor/pendingAgreement', 'SubcontractorController@pendingAgreement');
Route::get('subcontractor/accepetAgreement/{id}', 'SubcontractorController@accepetAgreement');


/************************ Users *************************/

Route::get('users/showUsers', 'UsersController@showUsers');
Route::get('users/showSuppliers', 'UsersController@showSuppliers');
Route::get('users/showSubcontractor', 'UsersController@showSubcontractor');
Route::get('users/pendingSuppliers', 'UsersController@pendingSuppliers');
Route::get('users/pendingSubcontractor', 'UsersController@pendingSubcontractor');
Route::get('users/approveUser/{id}', 'UsersController@approveUser');

Route::get('users/add/{id?}', 'UsersController@add');
Route::post('users/addUser', 'UsersController@addUser');
Route::get('users/showuserprofiel/{id}', 'UsersController@showuserprofiel');
Route::get('users/usersrules/{id}', 'UsersController@usersrules');
Route::post('users/setTheRules', 'UsersController@setTheRules');

Route::get('users/showPositions', 'UsersController@showPositions');
Route::get('users/addPosition/{id?}', 'UsersController@addPosition');
Route::post('users/setThePositions', 'UsersController@setThePositions');
Route::get('users/positionUsers/{id}', 'UsersController@positionUsers');




/************************ Material Requisition *************************/
Route::get('materialrequisition/add/{id}', 'MaterialrequisitionController@add');
Route::get('materialrequisition/show', 'MaterialrequisitionController@show');
Route::get('materialrequisition/pending', 'MaterialrequisitionController@pending');
Route::get('materialrequisition/approvePending/{id}', 'MaterialrequisitionController@approvePending');
Route::get('materialrequisition/approveReqPending/{id}', 'MaterialrequisitionController@approveReqPending');
Route::get('materialrequisition/approveLpoPending/{id}', 'MaterialrequisitionController@approveLpoPending');
Route::get('materialrequisition/markasDelivered/{id}', 'MaterialrequisitionController@markasDelivered');
Route::get('materialrequisition/markaspaid/{id}', 'MaterialrequisitionController@markaspaid');
Route::get('materialrequisition/reqPending', 'MaterialrequisitionController@reqPending');
Route::get('materialrequisition/lpoPending', 'MaterialrequisitionController@lpoPending');
Route::get('materialrequisition/awaiting', 'MaterialrequisitionController@awaiting');
Route::get('materialrequisition/delivered', 'MaterialrequisitionController@delivered');
Route::get('materialrequisition/checkout/{id}', 'MaterialrequisitionController@checkout');
Route::post('materialrequisition/addrequisition', 'MaterialrequisitionController@addrequisition');




