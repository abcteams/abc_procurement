$(function() {
    $('.select2').select2();
});

function getSubGml(item){
    var subGml=$('#subGml');
    if(item.value != 0){
        subGml.prop('disabled', false);
        $.ajax({
            type: "GET",
            url: 'getsubgmlitems',
            data:{'gml_id':item.value},
            success: function(result) {
                var obj = JSON.parse(result);

                subGml.find('option').remove();
                if(obj.length > 0)
                {
                    subGml.append($("<option></option>")
                        .attr("value",'0')
                        .text('Choose Sub Gml'));

                    $.each(obj , function( index, value ) {
                        subGml.append($("<option></option>")
                            .attr("value",value.id)
                            .text(value.title));

                    });
                }else{
                    subGml.append($("<option></option>")
                        .attr("value",'0')
                        .text('No Sub Items'));
                }
            }
        });
    }else{
        subGml.find('option').remove();
        subGml.append($("<option></option>")
            .attr("value",'0')
            .text('Choose Sub Gml'));

        subGml.prop('disabled', 'disabled');
    }

}



function delete_row(id){
    swal({
        title: "Are you sure?",
        text: "Are You sure you Want to Delete this record!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "GET",
                    url: 'removeMaterial',
                    data:{'id':id},
                    success: function(data) {
                        location.reload();
                    }
                });
            }
        });

}

function myProposalDetails(id) {
    alert(id);
}
function myProposalDetails(id){
    window.location = "/supplier/myProposalDetails/"+id;
}