<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class work_zones extends Model
{
    public function fetchAll($search){

        $q  =   DB::table('work_zone');

        if(isset($search['value']) && trim($search['value']) != '')
        {
            $q->where('title','like','%'.$search['value'].'%');
        }

        $data   =   $q->orderBy('id', 'desc')->paginate(5);
        return $data;

        return $data;
    }


    public function getSub($id){
        $data   =   DB::table('sub_work_zone')
            ->where('work_zone_id', '=', $id)
            ->orderBy('id', 'desc')->get();
        return $data;
    }

    public function getRecord($id){
        $data = DB::table('work_zone')->where('id', '=', $id)->get();

        return $data;
    }

    public function addRecord($data){
        DB::table('work_zone')->insert(
            ['title' => $data['title']]
        );
        return;
    }

    public function updateRecord($data){
        DB::table('work_zone')
            ->where('id', $data['id'])
            ->update(['title' => $data['title']]);
        return;
    }

    public function addSubRecord($data){
        DB::table('sub_work_zone')->insert(
            ['work_zone_id' => $data['workzoneId'],'title' => $data['title']]
        );
    }

    public function updateSubRecord($data){
        DB::table('sub_work_zone')
            ->where('id', $data['id'])
            ->update(['title' => $data['title']]);
    }

    public function getSubRecord($id){
        $data = DB::table('sub_work_zone')->where('id', '=', $id)->get();

        return $data;
    }

    public function workzoneSearch($data){
        $result = DB::table('work_zone')->where('title', 'like', '%'.$data['search'].'%')->orderBy('id', 'desc')->get();

        return $result;
    }

    public function serachSubZone($data){
        $result = DB::table('sub_work_zone')->where('work_zone_id', '=', $data['workzoneId'])->where('title', 'like', '%'.$data['search'].'%')->orderBy('id', 'desc')->get();

        return $result;
    }



    public function checkWorkZoneIsUsed($id){
        $count  =   DB::table('sub_work_zone')->where('work_zone_id','=',$id)->count();
        return $count;
    }

    public function removeRec($id)
    {
        DB::table('work_zone')->where('id', '=', $id)->delete();
    }


    public function checkSubWorkZoneIsUsed($id){
        $count1  =   DB::table('boq')->where('sub_work_zone_id','=',$id)->count();
        $count2  =   DB::table('scr')->where('sub_work_zone_id','=',$id)->count();
        $count  =   intval($count1) + intval($count2);
        return $count;
    }


    public function removeSubWorkZone($id)
    {
        DB::table('sub_work_zone')->where('id', '=', $id)->delete();
    }
}
