<?php

namespace App\Http\Controllers;

use App\gml;
use App\important\checkMenu;
use Illuminate\Http\Request;
use App\important\checkAuth;

class GmlController extends Controller
{
    private $menu;
    private $checkAuth;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->menu         =   new checkMenu();
        $this->checkAuth    =   new checkAuth();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function show(Request $request)
    {
        $authGml        =   $this->checkAuth->checkGML();
        $menuData   =   $this->menu->Menu('gml','showGml');
        if($authGml->can_show)
        {
            $search['type']     =   $request->type;
            $search['value']    =   $request->value;

            $gml    =   new gml();
            $data   =   $gml->fetchAll($search);
            return view('GML.gml')->with('menu',$menuData)->with('data',$data)->with('auth',$authGml);
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function showsub(Request $request){
        $authGml        =   $this->checkAuth->checkGML();
        $menuData   =   $this->menu->Menu('gml','');
        if($authGml->can_show)
        {
            $search['type']     =   $request->type;
            $search['value']    =   $request->value;
            $search['id']       =   $request->id;
            $gml    =   new gml();
            $data   =   $gml->getSub($search);
            return view('GML.subgml')->with('menu',$menuData)->with('data',$data)->with('gmlId',$request->id)->with('auth',$authGml);
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function add(Request $request){
        $authGml        =   $this->checkAuth->checkGML();
        $menuData   =   $this->menu->Menu('gml','addGml');
        if($authGml->can_edit) {
            if (isset($request->id) && $request->id > 0) {
                $gml = new gml();
                $data = $gml->getRecord($request->id);

                return view('GML.add')->with('menu', $menuData)->with('theRecord', $data);
            } else {
                return view('GML.add')->with('menu', $menuData)->with('subMenu', 'add');
            }
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }

    }

    public function addGml(Request $request){

        $this->validate($request, [
            'title' => 'required',
        ]);

        $authGml        =   $this->checkAuth->checkGML();
        $menuData   =   $this->menu->Menu('gml','showGml');
        if($authGml->can_edit) {
            $data   =   array();
            $data['title']  =   $request->title;
            $data['desc']   =   $request->description;

            if(isset($request->id )&& $request->id > 0) {
                $data['id']   =   $request->id;
                $gml    =   new gml();
                $gml->updateRecord($data);
            }else{
                $gml    =   new gml();
                $gml->addRecord($data);
            }

            return redirect('gml/show')->with('menu', $menuData);
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }
    }



    public function addsub(Request $request){
        $authGml        =   $this->checkAuth->checkGML();
        $menuData   =   $this->menu->Menu('gml','');
        if($authGml->can_edit) {

            if (isset($request->gmlId) && $request->gmlId) {
                if (isset($request->id) && $request->id > 0) {
                    $gml = new gml();
                    $data = $gml->getSubRecord($request->id);

                    return view('GML.addsub')->with('menu', $menuData)->with('theRecord', $data)->with('gmlId', $request->gmlId);
                } else {
                    return view('GML.addsub')->with('menu', $menuData)->with('gmlId', $request->gmlId);
                }
            }
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }

    }

    public function addsubgml(Request $request){

        $this->validate($request, [
            'title' => 'required',
        ]);

        $authGml        =   $this->checkAuth->checkGML();
        if($authGml->can_edit) {
            if (isset($request->gmlId) && $request->gmlId > 0) {
                $data = array();
                $data['gmlId'] = $request->gmlId;
                $data['title'] = $request->title;
                $data['desc'] = $request->description;

                if (isset($request->id) && $request->id > 0) {
                    $data['id'] = $request->id;
                    $gml = new gml();
                    $gml->updateSubRecord($data);
                } else {
                    $gml = new gml();
                    $gml->addSubRecord($data);
                }
            }
        }

        return redirect('gml/showsub/'.$request->gmlId);
    }


    public function gmlSearch(Request $request){
        $data['type']       =   $request->type;
        $data['search']     =   $request->search;

        $gml    =   new gml();
        $result =   $gml->searchGml($data);

            die(json_encode($result));
            die('0');
    }

    public function subGmlSearch(Request $request){
        $data['gml_id']       =   $request->gml_id;
        $data['type']       =   $request->type;
        $data['search']     =   $request->search;

        $gml    =   new gml();
        $result =   $gml->searchSubGml($data);

        die(json_encode($result));
        die('0');
    }

    public function removegml(Request $request)
    {
        $authGml = $this->checkAuth->checkGML();
        if ($authGml->can_edit) {
            $gml    = new gml();
            $recNumber   = $gml->checkGmlIsUsed($request->id);
            if(intval($recNumber) > 0){
                die('This Record Is Used , You Cant Remove it');
            }else{
                $gml->removeRec($request->id);
            }
        }
        die();
    }
    public function removesubgml(Request $request){
        $authGml = $this->checkAuth->checkGML();
        if ($authGml->can_edit) {
            $gml = new gml();
            $subRecNumber   = $gml->checkSubGmlIsUsed($request->id);
            if(intval($subRecNumber) > 0){
                die('This Record Is Used , You Cant Remove it');
            }else{
                $gml->removeSubGml($request->id);
            }

        }
        die();
    }

    public function pendingSub(Request $request)
    {
        $menuData   =   $this->menu->Menu('gml','pendingGml');
        $authGml = $this->checkAuth->checkGML();
        if ($authGml->can_approve) {
        $gml    =   new gml();
        $data = $gml->getPending($request->id);

        return view ('GML.pending')->with('menu',$menuData)->with('data',$data);
        }else{
            redirect(asset('home'))->with('menu', $menuData);
        }
    }

    public function approvePending(Request $request){
        $authGml = $this->checkAuth->checkGML();
        if ($authGml->can_approve) {
            if (isset($request->id) && $request->id > 0) {
                $gml = new gml();
                $data = $gml->approvePending($request->id);
            }
            return back();
        }
    }


}

